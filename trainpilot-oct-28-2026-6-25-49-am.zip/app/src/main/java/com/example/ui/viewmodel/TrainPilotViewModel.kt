package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import com.example.data.DemoDataProvider
import com.example.model.AppLanguage
import com.example.model.CalendarDayEvent
import com.example.model.CalendarEventStatus
import com.example.model.ExerciseCategory
import com.example.model.ExerciseItem
import com.example.model.ExerciseSetItem
import com.example.model.HomeDemoMode
import com.example.model.LoggedWorkoutEntry
import com.example.model.MainTab
import com.example.model.PrRecordEntry
import com.example.model.TrainingProgramModel
import com.example.model.SubScreen
import com.example.ui.theme.PaletteCategory
import com.example.ui.theme.TrainPilotPalettes
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import android.content.Context
import androidx.compose.ui.graphics.toArgb
import com.repforge.app.ActiveWorkoutStore
import com.repforge.app.HealthBackgroundJob
import com.repforge.app.HealthJournalStore
import com.repforge.app.PhoneWorkoutExecution
import com.repforge.app.WearSyncRepository
import com.repforge.app.data.db.BodyWeightEntryEntity
import com.repforge.app.data.db.TrainPilotDatabase
import com.repforge.app.data.migration.LegacyWebViewMigrator
import com.repforge.app.data.store.ThemePaletteOption
import com.repforge.app.data.store.TrainPilotSettingsStore
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID

data class NavRoute(
    val tab: MainTab,
    val subScreen: SubScreen = SubScreen.NONE
)

data class TrainPilotUiState(
    // Theme & Localization & Accessibility
    val selectedPaletteId: Int = 1, // Default: 01 • Grafit & Arany
    val paletteFilterCategory: PaletteCategory? = null, // null = All 32
    val showPalettePickerSheet: Boolean = false,
    val language: AppLanguage = AppLanguage.HU,
    val fontScaleMultiplier: Float = 1.0f,
    val compactPhoneMode: Boolean = false,

    // Navigation & Backstack
    val currentTab: MainTab = MainTab.HOME,
    val currentSubScreen: SubScreen = SubScreen.NONE,
    val backStack: List<NavRoute> = emptyList(),

    // Home Screen State (Mockup 1/4 #1 + main Home)
    val homeDemoMode: HomeDemoMode = HomeDemoMode.PAUSED_WORKOUT,
    val weeklyGoalCompleted: Int = 1,
    val weeklyGoalTarget: Int = 15,
    val showGoalsDialog: Boolean = false,
    val showPersonalPlannerModal: Boolean = false,
    val showQuickWorkoutSheet: Boolean = false,
    val sleepDurationLabel: String = "7 ó 24 p",
    val sleepHoursDecimal: String = "6,2 h",
    val restingHrBpm: Int = 62,
    val currentHrBpm: Int = 65,
    val dailySteps: Int = 8421,
    val stepsGoal: Int = 10000,
    val activeCaloriesKcal: Int = 164,
    val samsungEnergyScore: Int = 87,
    val coachReadinessScore: Int = 54,

    // Watch & Sync State (Mockup 4/4 #2 + main)
    val watchName: String = "Galaxy Watch7",
    val watchConnected: Boolean = true,
    val watchBatteryPercent: Int = 92,
    val phoneControlsWorkout: Boolean = true,
    val offlineContinuationEnabled: Boolean = true,
    val lastWatchSyncLabel: String = "Ma 09:24",
    val autoDriveSync: Boolean = true,
    val autoCalendarSync: Boolean = true,
    val lastDriveSyncLabel: String = "2026. 10. 20. 05:29",
    val lastCalendarSyncLabel: String = "2026. 10. 27. 11:29",

    // Programs & Program Editor State (Mockup 1/4 #3 + 4/4 #6 + main)
    val programs: List<TrainingProgramModel> = DemoDataProvider.defaultPrograms,
    val programsTabCustomOnly: Boolean = true,
    val editingProgramId: String = "home_ab_basic",
    val editingDayIndex: Int = 0,
    val expandedEditorExerciseId: String? = "band_row",
    val showProgressionModal: Boolean = false,
    val trainingStyleHu: String = "Normál hipertrófia",
    val progressionRuleHu: String = "Dupla progresszió",
    val beginnerGentleProfileActive: Boolean = false,

    // Calendar & Replan State (Mockup 1/4 #4 + main Naptár & Újratervezés)
    val selectedCalendarDay: Int = 24,
    val calendarEvents: List<CalendarDayEvent> = DemoDataProvider.initialCalendarEvents,
    val showReplanModal: Boolean = false,
    val planningCadenceHu: String = "Minden másodnap",
    val planningFirstDayHu: String = "Alap A",
    val planningStartDate: String = "2026. 10. 27.",
    val planningTime: String = "10:00",
    val planningDurationMin: Int = 60,
    val planningWeeksCount: Int = 4,

    // Exercise Library & Detail State (Mockup 1/4 #5 & #6)
    val exercises: List<ExerciseItem> = DemoDataProvider.defaultExercises,
    val exerciseSearchQuery: String = "",
    val selectedExerciseCategory: ExerciseCategory = ExerciseCategory.ALL,
    val selectedExerciseId: String = "goblet_squat",
    val showAddCustomExerciseDialog: Boolean = false,

    // Active Workout & Measurement State (Mockup 2/4 #1..#6)
    val activeExerciseIndex: Int = 0,
    val activeSets: List<ExerciseSetItem> = listOf(
        ExerciseSetItem(1, 16f, 10, 2, true),
        ExerciseSetItem(2, 16f, 10, 1, true),
        ExerciseSetItem(3, 16f, 10, 1, false)
    ),
    val restTimerRemainingSec: Int = 52,
    val restTimerRunning: Boolean = true,
    val defaultRestSec: Int = 90,
    val soundAlertEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val autoStepIntervals: Boolean = true,
    val intervalWorkSec: Int = 30,
    val intervalRestSec: Int = 60,
    val intervalRounds: Int = 3,
    val timedCurrentSec: Int = 38,
    val bilateralLeftSec: Int = 25,
    val bilateralRightSec: Int = 18,
    val outdoorGpsEnabled: Boolean = true,
    val outdoorDistanceKm: Float = 1.62f,
    val outdoorElapsedLabel: String = "09:42",
    val outdoorPaceLabel: String = "6:00",
    val workoutSummaryMoodIndex: Int = 2, // 2 = "Pont jó"
    val workoutSummaryNote: String = "",

    // Log / Diary State (Mockup 3/4 #1..#3 + main)
    val logSearchQuery: String = "",
    val selectedLogMonth: String = "2026. október",
    val loggedWorkouts: List<LoggedWorkoutEntry> = DemoDataProvider.initialLoggedWorkouts,
    val selectedLogWorkoutId: String = "log_4",
    val logDetailTabIndex: Int = 0, // 0 = Gyakorlatok, 1 = Statisztikák, 2 = Forrás
    val expandedLogExerciseIndex: Int = 0,

    // Progress / Fejlődés State (Mockup 3/4 #4 + full main Fejlődés & Statisztikák)
    val progressMainSection: Int = 0, // 0 = Kompakt Fejlődés (main), 1 = Statisztikák (Rekordok & Kardió), 2 = 1RM Erőnlét
    val selectedProgressExercise: String = "Fekvenyomás",
    val selectedProgressRangeIndex: Int = 3, // 0 = 1 nap, 1 = 7 nap, 2 = 30 nap, 3 = 3 hó
    val selectedVolumeBarIndex: Int = 9,
    val expandedStatsCardIndex: Int = -1, // -1 = collapsed; 0 = PR rekordok (45), 1 = Edzések száma (25), 2 = Átlagos volumen (904,3 kg), 3 = Átl. edzésidő (45 min)
    val statsSubTab: Int = 0, // 0 = Személyes rekordok, 1 = Kardióstatisztika
    val cardioFilterStepsMode: Boolean = false, // false = Minden mozgás, true = Napi aktivitás / lépések
    val prRecords: List<PrRecordEntry> = DemoDataProvider.prRecords,
    val videoModalExerciseTitle: String? = null,

    // Health / Egészség State (Mockup 3/4 #5 + full main Egészség)
    val expandedHealthPulseTrend: Boolean = false,
    val expandedHealthWeightLog: Boolean = false,
    val expandedHealthExtraData: Boolean = false,
    val expandedHealthJournal: Boolean = false,
    val expandedHealthConnect: Boolean = false,
    val selectedWeightRangeIndex: Int = 1, // 0=7d, 1=30d, 2=3m, 3=1y, 4=All
    val currentBodyWeightKg: Float = 65.0f,
    val bodyFatPercent: Float = 18.3f,
    val spo2Percent: Float = 97.0f,
    val vo2Max: Float = 38.6f,
    val showAddWeightDialog: Boolean = false,
    val primaryHealthSourceSamsung: Boolean = true,

    // Permissions & Backup State (Mockup 4/4 #3, #4, #5)
    val selectedBackupFormat: String = "JSON", // JSON, ZIP, DRIVE
    val includeHealthInBackup: Boolean = true,
    val permissionGpsEnabled: Boolean = true,
    val permissionCentralLocEnabled: Boolean = true,
    val permissionNotificationsEnabled: Boolean = true,
    val permissionHealthConnectEnabled: Boolean = true,
    val permissionSamsungHealthEnabled: Boolean = false,
    val privatePhotoCount: Int = 2,

    // Toast / Feedback banner for immediate visual confirmation of actions
    val statusBannerMessage: String? = null
)

class TrainPilotViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(TrainPilotUiState())
    val uiState: StateFlow<TrainPilotUiState> = _uiState.asStateFlow()

    private var nativeContext: Context? = null
    private var nativeSettingsStore: TrainPilotSettingsStore? = null
    private var nativeDatabase: TrainPilotDatabase? = null
    private var nativeScope: CoroutineScope? = null

    fun bindNativeEnvironment(
        context: Context,
        settingsStore: TrainPilotSettingsStore,
        database: TrainPilotDatabase,
        scope: CoroutineScope
    ) {
        nativeContext = context
        nativeSettingsStore = settingsStore
        nativeDatabase = database
        nativeScope = scope

        scope.launch(Dispatchers.IO) {
            // 1. Detect if a paused or active workout is running natively
            try {
                val execution = PhoneWorkoutExecution.store(context).snapshot()
                val activeStore = ActiveWorkoutStore.current(context)
                val isPaused = (execution?.optBoolean("active") == true && execution.optBoolean("workoutPaused")) ||
                        (activeStore?.optBoolean("active") == true && activeStore.optBoolean("workoutPaused"))
                val isRunning = (execution?.optBoolean("active") == true && !execution.optBoolean("workoutPaused")) ||
                        (activeStore?.optBoolean("active") == true && !activeStore.optBoolean("workoutPaused"))

                if (isPaused || isRunning) {
                    _uiState.update { it.copy(homeDemoMode = HomeDemoMode.PAUSED_WORKOUT) }
                } else {
                    _uiState.update { it.copy(homeDemoMode = HomeDemoMode.PLANNED_NEXT) }
                }
            } catch (_: Throwable) {}

            // 2. Read latest body weight from Room
            try {
                val weightSummary = database.bodyWeightDao().getWeightJournalSummary()
                if (weightSummary.currentKg != null && weightSummary.currentKg > 0.0) {
                    _uiState.update { it.copy(currentBodyWeightKg = weightSummary.currentKg.toFloat()) }
                }
            } catch (_: Throwable) {}

            // 3. Read persisted workouts from Room
            try {
                val dbWorkouts = database.workoutHistoryDao().getAllWorkoutsWithDetails()
                if (dbWorkouts.isNotEmpty()) {
                    val mapped = dbWorkouts.map { detail ->
                        val w = detail.workout
                        val exerciseNames = detail.exercises.joinToString(", ") { exWithSets ->
                            val ex = exWithSets.exercise
                            ex.nameHu.ifBlank { ex.exerciseId }
                        }
                        val allSets = detail.exercises.flatMap { it.sets }
                        val isOutdoor = detail.exercises.any {
                            val ex = it.exercise
                            ex.measurementType == "distance" || ex.repUnit == "km"
                        }
                        LoggedWorkoutEntry(
                            id = w.id,
                            dateLabelHu = w.started.take(16).replace('T', ' '),
                            titleHu = w.programName.ifBlank { w.dayName }.ifBlank { "Edzés" },
                            durationMinutes = if (w.finishedEpochMs > w.startedEpochMs) ((w.finishedEpochMs - w.startedEpochMs) / 60000).toInt() else 45,
                            workTimeLabel = "30:00",
                            restTimeLabel = "15:00",
                            totalSets = if (w.completedSetsCount > 0) w.completedSetsCount else allSets.size,
                            totalVolumeKg = if (w.totalVolumeKg > 0.0) w.totalVolumeKg.toInt() else allSets.sumOf { ((it.weight ?: 0.0) * (it.reps.toIntOrNull() ?: 0)).toInt() },
                            summaryExercisesHu = exerciseNames.ifBlank { "Rögzített gyakorlatok" },
                            hasPr = w.hasPr226,
                            isOutdoorRun = isOutdoor
                        )
                    }
                    _uiState.update { current ->
                        current.copy(loggedWorkouts = mapped + current.loggedWorkouts)
                    }
                }
            } catch (_: Throwable) {}

            // 4. Read real daily health projections from HealthJournalStore
            try {
                val store = HealthJournalStore.get(context)
                val projection = store.projection()
                val todayStr = LocalDate.now().toString()
                val todayData = projection.optJSONObject("days")?.optJSONObject(todayStr)
                if (todayData != null) {
                    val steps = todayData.optInt("steps", -1)
                    val restingHr = todayData.optInt("restingHeartRate", -1)
                    val currentHr = todayData.optInt("heartRate", -1)
                    val sleepSec = todayData.optInt("sleepDurationSeconds", -1)
                    _uiState.update { st ->
                        st.copy(
                            dailySteps = if (steps > 0) steps else st.dailySteps,
                            restingHrBpm = if (restingHr > 0) restingHr else st.restingHrBpm,
                            currentHrBpm = if (currentHr > 0) currentHr else st.currentHrBpm,
                            sleepDurationLabel = if (sleepSec > 0) String.format("%d ó %d p", sleepSec / 3600, (sleepSec % 3600) / 60) else st.sleepDurationLabel
                        )
                    }
                }
            } catch (_: Throwable) {}
        }
    }

    fun selectTab(tab: MainTab) {
        _uiState.update { state ->
            if (state.currentTab == tab && state.currentSubScreen == SubScreen.NONE) {
                state
            } else {
                val updatedStack = (state.backStack + NavRoute(state.currentTab, state.currentSubScreen)).takeLast(16)
                state.copy(
                    currentTab = tab,
                    currentSubScreen = SubScreen.NONE,
                    backStack = updatedStack
                )
            }
        }
    }

    fun navigateToSubScreen(subScreen: SubScreen, targetTab: MainTab? = null) {
        _uiState.update { state ->
            val updatedStack = (state.backStack + NavRoute(state.currentTab, state.currentSubScreen)).takeLast(16)
            state.copy(
                currentTab = targetTab ?: state.currentTab,
                currentSubScreen = subScreen,
                backStack = updatedStack
            )
        }
    }

    fun navigateBack(): Boolean {
        val current = _uiState.value
        if (current.backStack.isNotEmpty()) {
            val previous = current.backStack.last()
            _uiState.update {
                it.copy(
                    currentTab = previous.tab,
                    currentSubScreen = previous.subScreen,
                    backStack = it.backStack.dropLast(1)
                )
            }
            return true
        } else if (current.currentSubScreen != SubScreen.NONE) {
            _uiState.update { it.copy(currentSubScreen = SubScreen.NONE) }
            return true
        } else if (current.currentTab != MainTab.HOME) {
            _uiState.update { it.copy(currentTab = MainTab.HOME) }
            return true
        }
        return false
    }

    fun selectPalette(paletteId: Int) {
        _uiState.update {
            it.copy(
                selectedPaletteId = paletteId,
                statusBannerMessage = "Színpaletta frissítve (#$paletteId)"
            )
        }
        val store = nativeSettingsStore
        val scope = nativeScope
        if (store != null && scope != null) {
            val pal = TrainPilotPalettes.getById(paletteId)
            val hexAccent = "#" + (pal.primary.value.toLong() and 0xFFFFFFL).toString(16).padStart(6, '0')
            val hexAccent2 = "#" + (pal.secondary.value.toLong() and 0xFFFFFFL).toString(16).padStart(6, '0')
            val option = ThemePaletteOption(
                key = pal.key,
                nameHu = pal.nameHu,
                nameEn = pal.nameEn,
                accent = hexAccent,
                accent2 = hexAccent2,
                family = if (pal.category == PaletteCategory.VIVID) "vivid" else "basic",
                nameDe = pal.nameDe,
                nameRo = pal.nameRo
            )
            scope.launch(Dispatchers.IO) {
                try { store.setTheme(option) } catch (_: Throwable) {}
            }
        }
    }

    fun setPaletteFilterCategory(category: PaletteCategory?) {
        _uiState.update { it.copy(paletteFilterCategory = category) }
    }

    fun togglePalettePickerSheet(show: Boolean) {
        _uiState.update { it.copy(showPalettePickerSheet = show) }
    }

    fun selectLanguage(lang: AppLanguage) {
        _uiState.update {
            it.copy(
                language = lang,
                statusBannerMessage = "Nyelv: ${lang.label} (${lang.code})"
            )
        }
        val store = nativeSettingsStore
        val scope = nativeScope
        if (store != null && scope != null) {
            scope.launch(Dispatchers.IO) {
                try { store.setLanguage(lang.code.lowercase()) } catch (_: Throwable) {}
            }
        }
    }

    fun setFontScaleMultiplier(scale: Float) {
        _uiState.update { it.copy(fontScaleMultiplier = scale) }
    }

    fun toggleCompactPhoneMode(compact: Boolean) {
        _uiState.update { it.copy(compactPhoneMode = compact) }
    }

    fun cycleHomeDemoMode(mode: HomeDemoMode) {
        _uiState.update {
            val readiness = if (mode == HomeDemoMode.COACH_LIGHT_DAY) 54 else 87
            it.copy(
                homeDemoMode = mode,
                coachReadinessScore = readiness,
                samsungEnergyScore = if (mode == HomeDemoMode.COACH_LIGHT_DAY) 61 else 87
            )
        }
    }

    fun toggleGoalsDialog(show: Boolean) {
        _uiState.update { it.copy(showGoalsDialog = show) }
    }

    fun updateGoals(weeklyTarget: Int, stepsTarget: Int) {
        _uiState.update {
            it.copy(
                weeklyGoalTarget = weeklyTarget.coerceIn(1, 30),
                stepsGoal = stepsTarget.coerceIn(2000, 30000),
                showGoalsDialog = false,
                statusBannerMessage = "Célok elmentve: $weeklyTarget edzés, $stepsTarget lépés"
            )
        }
    }

    fun togglePersonalPlannerModal(show: Boolean) {
        _uiState.update { it.copy(showPersonalPlannerModal = show) }
    }

    fun toggleQuickWorkoutSheet(show: Boolean) {
        _uiState.update { it.copy(showQuickWorkoutSheet = show) }
    }

    // Program & Exercise Editor Actions
    fun setProgramsTabCustomOnly(customOnly: Boolean) {
        _uiState.update { it.copy(programsTabCustomOnly = customOnly) }
    }

    fun activateProgram(programId: String) {
        _uiState.update { state ->
            val updated = state.programs.map { prog ->
                prog.copy(isActive = prog.id == programId)
            }
            state.copy(
                programs = updated,
                editingProgramId = programId,
                statusBannerMessage = "Aktív program frissítve"
            )
        }
    }

    fun openProgramEditor(programId: String, dayIndex: Int = 0) {
        _uiState.update {
            val back = (it.backStack + NavRoute(it.currentTab, it.currentSubScreen)).takeLast(16)
            it.copy(
                editingProgramId = programId,
                editingDayIndex = dayIndex,
                currentSubScreen = SubScreen.PROGRAM_EDITOR,
                backStack = back
            )
        }
    }

    fun selectEditingDayIndex(dayIndex: Int) {
        _uiState.update { it.copy(editingDayIndex = dayIndex) }
    }

    fun toggleExpandedEditorExercise(exerciseId: String) {
        _uiState.update {
            it.copy(
                expandedEditorExerciseId = if (it.expandedEditorExerciseId == exerciseId) null else exerciseId
            )
        }
    }

    fun updateProgramExercisePrescription(
        exerciseId: String,
        sets: Int,
        reps: Int,
        weightKg: Float,
        restSec: Int
    ) {
        _uiState.update { state ->
            val updatedPrograms = state.programs.map { prog ->
                if (prog.id != state.editingProgramId) prog
                else {
                    val updatedDays = prog.days.mapIndexed { idx, day ->
                        if (idx != state.editingDayIndex) day
                        else {
                            day.copy(
                                exercises = day.exercises.map { ex ->
                                    if (ex.id != exerciseId) ex
                                    else ex.copy(
                                        defaultSets = sets.coerceIn(1, 10),
                                        defaultReps = reps.coerceIn(1, 50),
                                        defaultWeightKg = weightKg.coerceAtLeast(0f),
                                        defaultRestSec = restSec.coerceIn(15, 300)
                                    )
                                }
                            )
                        }
                    }
                    prog.copy(days = updatedDays)
                }
            }
            state.copy(
                programs = updatedPrograms,
                expandedEditorExerciseId = null,
                statusBannerMessage = "Gyakorlat beállításai elmentve"
            )
        }
    }

    fun addExerciseToActiveProgramDay(exercise: ExerciseItem) {
        _uiState.update { state ->
            val updatedPrograms = state.programs.map { prog ->
                if (prog.id != state.editingProgramId) prog
                else {
                    val updatedDays = prog.days.mapIndexed { idx, day ->
                        if (idx != state.editingDayIndex) day
                        else if (day.exercises.any { it.id == exercise.id }) day
                        else day.copy(exercises = day.exercises + exercise)
                    }
                    prog.copy(days = updatedDays)
                }
            }
            state.copy(
                programs = updatedPrograms,
                statusBannerMessage = "${exercise.nameHu} hozzáadva az edzésnaphoz"
            )
        }
    }

    // Calendar & Replan Actions
    fun selectCalendarDay(day: Int) {
        _uiState.update { it.copy(selectedCalendarDay = day) }
    }

    fun toggleReplanModal(show: Boolean) {
        _uiState.update { it.copy(showReplanModal = show) }
    }

    fun applyCalendarReplan(newStartDate: String, firstDayHu: String) {
        _uiState.update { state ->
            val shiftedEvents = state.calendarEvents.map { ev ->
                if (ev.status == CalendarEventStatus.PLANNED && ev.dayOfMonth >= 27) {
                    ev.copy(dayOfMonth = (ev.dayOfMonth + 1).coerceAtMost(31))
                } else ev
            }
            state.copy(
                planningStartDate = newStartDate,
                planningFirstDayHu = firstDayHu,
                calendarEvents = shiftedEvents,
                showReplanModal = false,
                statusBannerMessage = "Edzésterv újratervezve ($newStartDate • $firstDayHu)"
            )
        }
    }

    // Exercise Library Actions
    fun updateExerciseSearch(query: String) {
        _uiState.update { it.copy(exerciseSearchQuery = query) }
    }

    fun selectExerciseCategory(cat: ExerciseCategory) {
        _uiState.update { it.copy(selectedExerciseCategory = cat) }
    }

    fun openExerciseDetail(exerciseId: String) {
        _uiState.update {
            val back = (it.backStack + NavRoute(it.currentTab, it.currentSubScreen)).takeLast(16)
            it.copy(
                selectedExerciseId = exerciseId,
                currentSubScreen = SubScreen.EXERCISE_DETAIL,
                backStack = back
            )
        }
    }

    // Active Workout Actions
    fun toggleSetCompleted(setNumber: Int) {
        _uiState.update { state ->
            val updated = state.activeSets.map { s ->
                if (s.setNumber == setNumber) s.copy(completed = !s.completed) else s
            }
            state.copy(
                activeSets = updated,
                restTimerRemainingSec = state.defaultRestSec,
                restTimerRunning = true
            )
        }
    }

    fun adjustSetValues(setNumber: Int, deltaWeight: Float, deltaReps: Int, deltaRir: Int) {
        _uiState.update { state ->
            val updated = state.activeSets.map { s ->
                if (s.setNumber == setNumber) {
                    s.copy(
                        weightKg = (s.weightKg + deltaWeight).coerceAtLeast(0f),
                        reps = (s.reps + deltaReps).coerceIn(1, 50),
                        rir = (s.rir + deltaRir).coerceIn(0, 10)
                    )
                } else s
            }
            state.copy(activeSets = updated)
        }
    }

    fun undoLastCompletedSet() {
        _uiState.update { state ->
            val lastCompleted = state.activeSets.lastOrNull { it.completed }
            if (lastCompleted == null) state
            else {
                state.copy(
                    activeSets = state.activeSets.map {
                        if (it.setNumber == lastCompleted.setNumber) it.copy(completed = false) else it
                    },
                    statusBannerMessage = "${lastCompleted.setNumber}. sorozat visszavonva"
                )
            }
        }
    }

    fun adjustRestTimer(deltaSec: Int) {
        _uiState.update {
            it.copy(restTimerRemainingSec = (it.restTimerRemainingSec + deltaSec).coerceIn(0, 600))
        }
    }

    fun toggleRestTimerRunning() {
        _uiState.update { it.copy(restTimerRunning = !it.restTimerRunning) }
    }

    fun skipRestTimer() {
        _uiState.update { it.copy(restTimerRemainingSec = 0, restTimerRunning = false) }
    }

    fun updateIntervalSettings(workSec: Int, restSec: Int, rounds: Int, sound: Boolean, vibration: Boolean, autoStep: Boolean) {
        _uiState.update {
            it.copy(
                intervalWorkSec = workSec.coerceIn(10, 300),
                intervalRestSec = restSec.coerceIn(10, 300),
                intervalRounds = rounds.coerceIn(1, 20),
                soundAlertEnabled = sound,
                vibrationEnabled = vibration,
                autoStepIntervals = autoStep,
                statusBannerMessage = "Intervallumok: ${workSec}mp munka / ${restSec}mp pihenő × $rounds"
            )
        }
    }

    fun selectWorkoutSummaryMood(index: Int) {
        _uiState.update { it.copy(workoutSummaryMoodIndex = index) }
    }

    fun updateWorkoutSummaryNote(note: String) {
        _uiState.update { it.copy(workoutSummaryNote = note) }
    }

    fun finishAndSaveWorkout() {
        val state = _uiState.value
        val now = Instant.now()
        val nowMs = System.currentTimeMillis()
        val workoutId = UUID.randomUUID().toString()
        val completedSets = state.activeSets.filter { it.completed }
        val setsToSave = if (completedSets.isNotEmpty()) completedSets else state.activeSets
        val totalVolume = setsToSave.sumOf { (it.weightKg * it.reps).toInt() }
        val currentExName = state.exercises.getOrNull(state.activeExerciseIndex)?.nameHu ?: "Edzés"
        val durationMins = maxOf(1, state.timedCurrentSec / 60)

        val ctx = nativeContext
        val db = nativeDatabase
        val store = nativeSettingsStore
        val scope = nativeScope

        if (ctx == null || db == null || store == null || scope == null) {
            _uiState.update { it.copy(statusBannerMessage = "Hiba: A natív edzésmotor nem elérhető!") }
            return
        }

        scope.launch(Dispatchers.IO) {
            try {
                val exercisesArray = JSONArray()
                val exObj = JSONObject().apply {
                    put("id", state.selectedExerciseId)
                    put("exerciseId", state.selectedExerciseId)
                    put("nameHu", currentExName)
                    put("nameEn", currentExName)
                    put("loadType", "weight")
                    put("repUnit", "reps")
                    put("measurementType", "reps")
                    put("orderIndex", 0)
                    val setsArray = JSONArray()
                    setsToSave.forEachIndexed { _, s ->
                        setsArray.put(JSONObject().apply {
                            put("setId", UUID.randomUUID().toString())
                            put("setNumber", s.setNumber)
                            put("weight", s.weightKg.toDouble())
                            put("reps", s.reps.toString())
                            put("done", s.completed)
                            put("actualRir", s.rir)
                        })
                    }
                    put("sets", setsArray)
                }
                exercisesArray.put(exObj)

                val startedMs = nowMs - (durationMins * 60 * 1000L)
                val historyJson = JSONObject().apply {
                    put("id", workoutId)
                    put("workoutId", workoutId)
                    put("workoutKey", workoutId)
                    put("syncId", workoutId)
                    put("started", Instant.ofEpochMilli(startedMs).toString())
                    put("finished", now.toString())
                    put("startedEpochMs", startedMs)
                    put("finishedEpochMs", nowMs)
                    put("programId", state.editingProgramId)
                    put("programName", "Edzés – $currentExName")
                    put("dayId", "session")
                    put("dayName", currentExName)
                    put("totalVolumeKg", totalVolume.toDouble())
                    put("completedSetsCount", setsToSave.size)
                    put("totalSetsCount", setsToSave.size)
                    put("exercises", exercisesArray)
                }

                // Call native workout persistence
                LegacyWebViewMigrator(ctx, db, store).saveWorkoutJsonToRoom(historyJson)

                // Verify persistence by querying Room
                val savedInDb = db.workoutHistoryDao().getWorkoutWithDetails(workoutId)
                if (savedInDb != null) {
                    runCatching { ActiveWorkoutStore.clear(ctx) }
                    runCatching { WearSyncRepository.publishWatchHomeSnapshot(ctx) }

                    val newEntry = LoggedWorkoutEntry(
                        id = workoutId,
                        dateLabelHu = DateTimeFormatter.ofPattern("MMM d., E • HH:mm", Locale.getDefault()).format(java.time.LocalDateTime.now()),
                        titleHu = "$currentExName edzés",
                        durationMinutes = durationMins,
                        workTimeLabel = String.format("%02d:%02d", durationMins, 0),
                        restTimeLabel = "00:00",
                        totalSets = setsToSave.size,
                        totalVolumeKg = totalVolume,
                        summaryExercisesHu = currentExName,
                        hasPr = false,
                        isOutdoorRun = false
                    )

                    withContext(Dispatchers.Main) {
                        _uiState.update { st ->
                            st.copy(
                                loggedWorkouts = listOf(newEntry) + st.loggedWorkouts,
                                weeklyGoalCompleted = st.weeklyGoalCompleted + 1,
                                currentTab = MainTab.LOG,
                                currentSubScreen = SubScreen.NONE,
                                statusBannerMessage = "Edzés sikeresen mentve a Room adatbázisba!"
                            )
                        }
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        _uiState.update { st ->
                            st.copy(statusBannerMessage = "Hiba: Az edzés mentése nem igazolható vissza!")
                        }
                    }
                }
            } catch (e: Throwable) {
                android.util.Log.e("TrainPilotViewModel", "Failed to finalize workout", e)
                withContext(Dispatchers.Main) {
                    _uiState.update { st ->
                        st.copy(statusBannerMessage = "Hiba az edzés mentésekor: ${e.localizedMessage ?: "adatbázishiba"}")
                    }
                }
            }
        }
    }

    // Log / Diary Actions
    fun updateLogSearch(query: String) {
        _uiState.update { it.copy(logSearchQuery = query) }
    }

    fun openLogWorkoutDetail(workoutId: String) {
        _uiState.update {
            val back = (it.backStack + NavRoute(it.currentTab, it.currentSubScreen)).takeLast(16)
            it.copy(
                selectedLogWorkoutId = workoutId,
                currentSubScreen = SubScreen.LOG_WORKOUT_DETAIL,
                backStack = back
            )
        }
    }

    fun selectLogDetailTab(index: Int) {
        _uiState.update { it.copy(logDetailTabIndex = index) }
    }

    fun toggleExpandedLogExercise(index: Int) {
        _uiState.update {
            it.copy(expandedLogExerciseIndex = if (it.expandedLogExerciseIndex == index) -1 else index)
        }
    }

    // Progress / Fejlődés Actions
    fun selectProgressMainSection(section: Int) {
        _uiState.update { it.copy(progressMainSection = section) }
    }

    fun selectProgressExercise(name: String) {
        _uiState.update { it.copy(selectedProgressExercise = name) }
    }

    fun selectProgressRange(index: Int) {
        _uiState.update { it.copy(selectedProgressRangeIndex = index) }
    }

    fun selectVolumeBar(index: Int) {
        _uiState.update { it.copy(selectedVolumeBarIndex = index) }
    }

    fun selectExpandedStatsCard(index: Int) {
        _uiState.update {
            it.copy(expandedStatsCardIndex = if (it.expandedStatsCardIndex == index) -1 else index)
        }
    }

    fun selectStatsSubTab(index: Int) {
        _uiState.update { it.copy(statsSubTab = index) }
    }

    fun toggleCardioFilterStepsMode(stepsMode: Boolean) {
        _uiState.update { it.copy(cardioFilterStepsMode = stepsMode) }
    }

    fun openExerciseVideoModal(exerciseTitle: String) {
        _uiState.update { it.copy(videoModalExerciseTitle = exerciseTitle) }
    }

    fun closeExerciseVideoModal() {
        _uiState.update { it.copy(videoModalExerciseTitle = null) }
    }

    // Health / Egészség Actions
    fun openHealthAndExpand(
        pulse: Boolean = false,
        weight: Boolean = false,
        extra: Boolean = false,
        journal: Boolean = false,
        connect: Boolean = false
    ) {
        _uiState.update { state ->
            val back = (state.backStack + NavRoute(state.currentTab, state.currentSubScreen)).takeLast(16)
            state.copy(
                currentTab = MainTab.HEALTH,
                currentSubScreen = SubScreen.NONE,
                backStack = back,
                expandedHealthPulseTrend = pulse || state.expandedHealthPulseTrend,
                expandedHealthWeightLog = weight || state.expandedHealthWeightLog,
                expandedHealthExtraData = extra || state.expandedHealthExtraData,
                expandedHealthJournal = journal || state.expandedHealthJournal,
                expandedHealthConnect = connect || state.expandedHealthConnect
            )
        }
    }

    fun toggleHealthSection(section: String) {
        _uiState.update { state ->
            when (section) {
                "pulse" -> state.copy(expandedHealthPulseTrend = !state.expandedHealthPulseTrend)
                "weight" -> state.copy(expandedHealthWeightLog = !state.expandedHealthWeightLog)
                "extra" -> state.copy(expandedHealthExtraData = !state.expandedHealthExtraData)
                "journal" -> state.copy(expandedHealthJournal = !state.expandedHealthJournal)
                "connect" -> state.copy(expandedHealthConnect = !state.expandedHealthConnect)
                else -> state
            }
        }
    }

    fun selectWeightRange(index: Int) {
        _uiState.update { it.copy(selectedWeightRangeIndex = index) }
    }

    fun toggleAddWeightDialog(show: Boolean) {
        _uiState.update { it.copy(showAddWeightDialog = show) }
    }

    fun saveNewBodyWeight(weightKg: Float) {
        if (weightKg <= 20f || weightKg >= 350f) {
            _uiState.update { it.copy(statusBannerMessage = "Érvénytelen testsúly: 20 és 350 kg között adható meg!") }
            return
        }
        val db = nativeDatabase
        val scope = nativeScope
        if (db == null || scope == null) {
            _uiState.update { it.copy(statusBannerMessage = "Hiba: Az adatbázis nem elérhető!") }
            return
        }
        scope.launch(Dispatchers.IO) {
            try {
                val now = Instant.now()
                val todayKey = LocalDate.now().toString()
                val entry = BodyWeightEntryEntity(
                    id = UUID.randomUUID().toString(),
                    date = now.toString(),
                    dayKey = todayKey,
                    kg = weightKg.toDouble(),
                    updatedAt = System.currentTimeMillis(),
                    rawJson = JSONObject().put("kg", weightKg.toDouble()).put("date", now.toString()).toString()
                )
                db.bodyWeightDao().upsertWeight(entry)
                // Verify by reading back from DB!
                val verified = db.bodyWeightDao().getWeightJournalSummary()
                if (verified.currentKg != null && Math.abs(verified.currentKg - weightKg.toDouble()) < 0.1) {
                    withContext(Dispatchers.Main) {
                        _uiState.update {
                            it.copy(
                                currentBodyWeightKg = weightKg,
                                showAddWeightDialog = false,
                                statusBannerMessage = "Testsúlymérés sikeresen elmentve: $weightKg kg"
                            )
                        }
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        _uiState.update {
                            it.copy(statusBannerMessage = "Hiba: A testsúlymérés nem rögzült az adatbázisban!")
                        }
                    }
                }
            } catch (e: Throwable) {
                android.util.Log.e("TrainPilotViewModel", "Failed to save body weight to Room", e)
                withContext(Dispatchers.Main) {
                    _uiState.update {
                        it.copy(statusBannerMessage = "Nem sikerült elmenteni a testsúlymérést: ${e.localizedMessage ?: "adatbázishiba"}")
                    }
                }
            }
        }
    }

    fun togglePrimaryHealthSource() {
        _uiState.update {
            val next = !it.primaryHealthSourceSamsung
            it.copy(
                primaryHealthSourceSamsung = next,
                statusBannerMessage = if (next) "Elsődleges forrás: Samsung Health" else "Elsődleges forrás: Health Connect"
            )
        }
    }

    fun triggerHealthSyncNow() {
        val ctx = nativeContext
        val scope = nativeScope
        if (ctx == null || scope == null) {
            _uiState.update {
                it.copy(statusBannerMessage = "Az egészségügyi szolgáltatások nem elérhetők.")
            }
            return
        }
        scope.launch(Dispatchers.IO) {
            try {
                HealthBackgroundJob.schedule(ctx)
                WearSyncRepository.publishWatchHomeSnapshot(ctx)
                val store = HealthJournalStore.get(ctx)
                val projection = store.projection()
                val todayStr = LocalDate.now().toString()
                val todayData = projection.optJSONObject("days")?.optJSONObject(todayStr)

                val steps = todayData?.optInt("steps", -1) ?: -1
                val restingHr = todayData?.optInt("restingHeartRate", -1) ?: -1
                val currentHr = todayData?.optInt("heartRate", -1) ?: -1
                val sleepSec = todayData?.optInt("sleepDurationSeconds", -1) ?: -1
                val sleepStr = if (sleepSec > 0) String.format("%d ó %d p", sleepSec / 3600, (sleepSec % 3600) / 60) else null

                withContext(Dispatchers.Main) {
                    _uiState.update { st ->
                        st.copy(
                            dailySteps = if (steps > 0) steps else st.dailySteps,
                            restingHrBpm = if (restingHr > 0) restingHr else st.restingHrBpm,
                            currentHrBpm = if (currentHr > 0) currentHr else st.currentHrBpm,
                            sleepDurationLabel = sleepStr ?: st.sleepDurationLabel,
                            statusBannerMessage = "Egészségügyi szinkronizáció sikeresen lefutott!"
                        )
                    }
                }
            } catch (e: Throwable) {
                withContext(Dispatchers.Main) {
                    _uiState.update {
                        it.copy(statusBannerMessage = "Hiba az egészségszinkron során: ${e.localizedMessage ?: "szolgáltatói hiba"}")
                    }
                }
            }
        }
    }

    // Watch, Settings, Backup & Permissions Actions
    fun toggleWatchControlMode() {
        val ctx = nativeContext
        val scope = nativeScope
        if (ctx == null || scope == null) {
            _uiState.update { it.copy(statusBannerMessage = "A Wear OS szolgáltatás jelenleg nem elérhető.") }
            return
        }
        scope.launch(Dispatchers.IO) {
            try {
                val active = ActiveWorkoutStore.current(ctx)
                if (active == null || !active.optBoolean("active", false)) {
                    withContext(Dispatchers.Main) {
                        _uiState.update {
                            it.copy(
                                phoneControlsWorkout = true,
                                statusBannerMessage = "Nincs aktív edzés folyamatban az órára történő átadáshoz."
                            )
                        }
                    }
                    return@launch
                }
                val currentOwner = active.optString("timerOwner", "phone")
                if (currentOwner == "phone") {
                    WearSyncRepository.publishWatchHomeSnapshot(ctx)
                    withContext(Dispatchers.Main) {
                        _uiState.update {
                            it.copy(
                                phoneControlsWorkout = false,
                                lastWatchSyncLabel = "Szinkronizálva",
                                statusBannerMessage = "Edzés átadási kérelem elküldve az órának"
                            )
                        }
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        _uiState.update {
                            it.copy(
                                phoneControlsWorkout = true,
                                lastWatchSyncLabel = "Szinkronizálva",
                                statusBannerMessage = "Edzésvezérlés visszavéve a telefonra"
                            )
                        }
                    }
                }
            } catch (e: Throwable) {
                withContext(Dispatchers.Main) {
                    _uiState.update {
                        it.copy(statusBannerMessage = "Hiba az óra szinkronizációjakor: ${e.localizedMessage ?: "kapcsolati hiba"}")
                    }
                }
            }
        }
    }

    fun toggleSoundAlert(enabled: Boolean) {
        _uiState.update { it.copy(soundAlertEnabled = enabled) }
        val store = nativeSettingsStore
        val scope = nativeScope
        if (store != null && scope != null) {
            val current = _uiState.value
            scope.launch(Dispatchers.IO) {
                try {
                    store.setTimerDefaults(
                        workSeconds = 30,
                        restSeconds = current.defaultRestSec,
                        rounds = 3,
                        sound = enabled,
                        vibration = current.vibrationEnabled
                    )
                } catch (_: Throwable) {}
            }
        }
    }

    fun cycleDefaultRestTimer() {
        _uiState.update {
            val next = when (it.defaultRestSec) {
                60 -> 90
                90 -> 120
                120 -> 180
                else -> 60
            }
            it.copy(defaultRestSec = next, statusBannerMessage = "Alapértelmezett pihenőidő: $next mp")
        }
        val store = nativeSettingsStore
        val scope = nativeScope
        if (store != null && scope != null) {
            val current = _uiState.value
            scope.launch(Dispatchers.IO) {
                try {
                    store.setTimerDefaults(
                        workSeconds = 30,
                        restSeconds = current.defaultRestSec,
                        rounds = 3,
                        sound = current.soundAlertEnabled,
                        vibration = current.vibrationEnabled
                    )
                } catch (_: Throwable) {}
            }
        }
    }

    fun toggleProgressionModal(show: Boolean) {
        _uiState.update { it.copy(showProgressionModal = show) }
    }

    fun updateProgressionSettings(styleHu: String, ruleHu: String, gentleBeginner: Boolean) {
        _uiState.update {
            it.copy(
                trainingStyleHu = styleHu,
                progressionRuleHu = ruleHu,
                beginnerGentleProfileActive = gentleBeginner,
                showProgressionModal = false,
                statusBannerMessage = "Progresszió: $styleHu • $ruleHu"
            )
        }
    }

    fun selectBackupFormat(format: String) {
        _uiState.update { it.copy(selectedBackupFormat = format) }
    }

    fun toggleIncludeHealthInBackup(include: Boolean) {
        _uiState.update { it.copy(includeHealthInBackup = include) }
    }

    fun togglePermission(key: String) {
        _uiState.update { state ->
            when (key) {
                "gps" -> state.copy(permissionGpsEnabled = !state.permissionGpsEnabled)
                "central" -> state.copy(permissionCentralLocEnabled = !state.permissionCentralLocEnabled)
                "notif" -> state.copy(permissionNotificationsEnabled = !state.permissionNotificationsEnabled)
                "hc" -> state.copy(permissionHealthConnectEnabled = !state.permissionHealthConnectEnabled)
                "samsung" -> state.copy(permissionSamsungHealthEnabled = !state.permissionSamsungHealthEnabled)
                else -> state
            }
        }
    }

    fun showBannerMessage(message: String) {
        _uiState.update { it.copy(statusBannerMessage = message) }
    }

    fun clearBannerMessage() {
        _uiState.update { it.copy(statusBannerMessage = null) }
    }

    fun syncNativeSettings(
        languageCode: String,
        themeKey: String,
        restSec: Int = 90,
        sound: Boolean = true,
        vibration: Boolean = true
    ) {
        val lang = when (languageCode.lowercase()) {
            "en" -> AppLanguage.EN
            "de" -> AppLanguage.DE
            "ro" -> AppLanguage.RO
            else -> AppLanguage.HU
        }
        val palette = com.example.ui.theme.TrainPilotPalettes.getByKey(themeKey)
        _uiState.update { current ->
            current.copy(
                language = lang,
                selectedPaletteId = palette?.id ?: current.selectedPaletteId,
                defaultRestSec = if (restSec > 0) restSec else current.defaultRestSec,
                soundAlertEnabled = sound,
                vibrationEnabled = vibration
            )
        }
    }
}
