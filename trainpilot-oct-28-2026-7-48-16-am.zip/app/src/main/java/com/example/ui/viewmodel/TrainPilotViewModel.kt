package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import com.example.data.DemoDataProvider
import com.example.model.AppLanguage
import com.example.model.CalendarDayEvent
import com.example.model.CalendarEventStatus
import com.example.model.ExerciseCategory
import com.example.model.ExerciseItem
import com.example.model.ExerciseSetItem
import com.example.model.HomeDemoMode
import com.example.model.LoggedWorkoutEntry
import com.example.model.MainTab
import com.example.model.PrRecordEntry
import com.example.model.TrainingProgramModel
import com.example.model.SubScreen
import com.example.ui.theme.PaletteCategory
import com.example.ui.theme.TrainPilotPalettes
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import android.content.Context
import androidx.compose.ui.graphics.toArgb
import com.repforge.app.ActiveWorkoutStore
import com.repforge.app.HealthBackgroundJob
import com.repforge.app.HealthJournalStore
import com.repforge.app.PhoneWorkoutExecution
import com.repforge.app.WearSyncRepository
import com.repforge.app.data.db.BodyWeightEntryEntity
import com.repforge.app.data.db.TrainPilotDatabase
import com.repforge.app.data.migration.LegacyWebViewMigrator
import com.repforge.app.data.store.ThemePaletteOption
import com.repforge.app.data.store.TrainPilotSettingsStore
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID
import com.repforge.app.TrainPilotWorkoutFinalization
import com.repforge.app.NativeWorkoutSession
import com.repforge.app.PhoneOwnership193
import com.repforge.app.BackupRestoreManager
import com.repforge.app.ui.progress.NativeProgressQuery
import com.repforge.app.ui.progress.MuscleLoadUiModel
import android.net.Uri
import kotlin.math.roundToInt

data class NavRoute(
    val tab: MainTab,
    val subScreen: SubScreen = SubScreen.NONE
)

data class TrainPilotUiState(
    // Theme & Localization & Accessibility
    val selectedPaletteId: Int = 1, // Default: 01 • Grafit & Arany
    val paletteFilterCategory: PaletteCategory? = null, // null = All 32
    val showPalettePickerSheet: Boolean = false,
    val language: AppLanguage = AppLanguage.HU,
    val fontScaleMultiplier: Float = 1.0f,
    val compactPhoneMode: Boolean = false,

    // Navigation & Backstack
    val currentTab: MainTab = MainTab.HOME,
    val currentSubScreen: SubScreen = SubScreen.NONE,
    val backStack: List<NavRoute> = emptyList(),

    // Home Screen State (Mockup 1/4 #1 + main Home)
    val homeDemoMode: HomeDemoMode = HomeDemoMode.PLANNED_NEXT,
    val weeklyGoalCompleted: Int = 0,
    val weeklyGoalTarget: Int = 15,
    val showGoalsDialog: Boolean = false,
    val showPersonalPlannerModal: Boolean = false,
    val showQuickWorkoutSheet: Boolean = false,
    val sleepDurationLabel: String = "—",
    val sleepHoursDecimal: String = "—",
    val restingHrBpm: Int = 0,
    val currentHrBpm: Int = 0,
    val dailySteps: Int = 0,
    val stepsGoal: Int = 10000,
    val activeCaloriesKcal: Int = 0,
    val samsungEnergyScore: Int = 0,
    val coachReadinessScore: Int = 0,

    // Watch & Sync State (Mockup 4/4 #2 + main)
    val watchName: String = "Galaxy Watch",
    val watchConnected: Boolean = false,
    val watchBatteryPercent: Int = 0,
    val phoneControlsWorkout: Boolean = true,
    val watchControlPending: Boolean = false,
    val offlineContinuationEnabled: Boolean = true,
    val lastWatchSyncLabel: String = "—",
    val autoDriveSync: Boolean = false,
    val autoCalendarSync: Boolean = false,
    val lastDriveSyncLabel: String = "—",
    val lastCalendarSyncLabel: String = "—",

    // Programs & Program Editor State (Mockup 1/4 #3 + 4/4 #6 + main)
    val programs: List<TrainingProgramModel> = emptyList(),
    val programsTabCustomOnly: Boolean = false,
    val editingProgramId: String = "",
    val editingDayIndex: Int = 0,
    val expandedEditorExerciseId: String? = null,
    val showProgressionModal: Boolean = false,
    val trainingStyleHu: String = "Normál hipertrófia",
    val progressionRuleHu: String = "Dupla progresszió",
    val beginnerGentleProfileActive: Boolean = false,

    // Calendar & Replan State (Mockup 1/4 #4 + main Naptár & Újratervezés)
    val selectedCalendarDay: Int = 1,
    val calendarEvents: List<CalendarDayEvent> = emptyList(),
    val showReplanModal: Boolean = false,
    val planningCadenceHu: String = "Minden másodnap",
    val planningFirstDayHu: String = "Alap A",
    val planningStartDate: String = "2026. 10. 28.",
    val planningTime: String = "10:00",
    val planningDurationMin: Int = 60,
    val planningWeeksCount: Int = 4,

    // Exercise Library & Detail State (Mockup 1/4 #5 & #6)
    val exercises: List<ExerciseItem> = emptyList(),
    val exerciseSearchQuery: String = "",
    val selectedExerciseCategory: ExerciseCategory = ExerciseCategory.ALL,
    val selectedExerciseId: String = "",
    val showAddCustomExerciseDialog: Boolean = false,

    // Active Workout & Measurement State (Mockup 2/4 #1..#6)
    val activeExerciseIndex: Int = 0,
    val activeSets: List<ExerciseSetItem> = emptyList(),
    val restTimerRemainingSec: Int = 90,
    val restTimerRunning: Boolean = false,
    val defaultRestSec: Int = 90,
    val soundAlertEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val autoStepIntervals: Boolean = true,
    val intervalWorkSec: Int = 30,
    val intervalRestSec: Int = 60,
    val intervalRounds: Int = 3,
    val timedCurrentSec: Int = 0,
    val bilateralLeftSec: Int = 0,
    val bilateralRightSec: Int = 0,
    val outdoorGpsEnabled: Boolean = true,
    val outdoorDistanceKm: Float = 0f,
    val outdoorElapsedLabel: String = "00:00",
    val outdoorPaceLabel: String = "0:00",
    val workoutSummaryMoodIndex: Int = 2, // 2 = "Pont jó"
    val workoutSummaryNote: String = "",

    // Log / Diary State (Mockup 3/4 #1..#3 + main)
    val logSearchQuery: String = "",
    val selectedLogMonth: String = "2026. október",
    val loggedWorkouts: List<LoggedWorkoutEntry> = emptyList(),
    val selectedLogWorkoutId: String = "",
    val logDetailTabIndex: Int = 0, // 0 = Gyakorlatok, 1 = Statisztikák, 2 = Forrás
    val expandedLogExerciseIndex: Int = 0,

    // Progress / Fejlődés State (Mockup 3/4 #4 + full main Fejlődés & Statisztikák)
    val progressMainSection: Int = 0, // 0 = Kompakt Fejlődés (main), 1 = Statisztikák (Rekordok & Kardió), 2 = 1RM Erőnlét
    val selectedProgressExercise: String = "Fekvenyomás",
    val selectedProgressRangeIndex: Int = 3, // 0 = 1 nap, 1 = 7 nap, 2 = 30 nap, 3 = 3 hó
    val selectedVolumeBarIndex: Int = -1,
    val expandedStatsCardIndex: Int = -1,
    val statsSubTab: Int = 0, // 0 = Személyes rekordok, 1 = Kardióstatisztika
    val cardioFilterStepsMode: Boolean = false, // false = Minden mozgás, true = Napi aktivitás / lépések
    val prRecords: List<PrRecordEntry> = emptyList(),
    val videoModalExerciseTitle: String? = null,
    val realMuscleLoads: List<com.example.ui.components.MuscleLoadItem> = emptyList(),
    val muscleLoadPeriodDays: Int = 90,

    // Health / Egészség State (Mockup 3/4 #5 + full main Egészség)
    val expandedHealthPulseTrend: Boolean = false,
    val expandedHealthWeightLog: Boolean = false,
    val expandedHealthExtraData: Boolean = false,
    val expandedHealthJournal: Boolean = false,
    val expandedHealthConnect: Boolean = false,
    val selectedWeightRangeIndex: Int = 1, // 0=7d, 1=30d, 2=3m, 3=1y, 4=All
    val currentBodyWeightKg: Float = 0f,
    val bodyFatPercent: Float = 0f,
    val spo2Percent: Float = 0f,
    val vo2Max: Float = 0f,
    val showAddWeightDialog: Boolean = false,
    val primaryHealthSourceSamsung: Boolean = true,

    // Permissions & Backup State (Mockup 4/4 #3, #4, #5)
    val selectedBackupFormat: String = "JSON", // JSON, ZIP, DRIVE
    val includeHealthInBackup: Boolean = true,
    val permissionGpsEnabled: Boolean = true,
    val permissionCentralLocEnabled: Boolean = true,
    val permissionNotificationsEnabled: Boolean = true,
    val permissionHealthConnectEnabled: Boolean = true,
    val permissionSamsungHealthEnabled: Boolean = false,
    val privatePhotoCount: Int = 0,

    // Toast / Feedback banner for immediate visual confirmation of actions
    val statusBannerMessage: String? = null
)

class TrainPilotViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(TrainPilotUiState())
    val uiState: StateFlow<TrainPilotUiState> = _uiState.asStateFlow()

    private var nativeContext: Context? = null
    private var nativeSettingsStore: TrainPilotSettingsStore? = null
    private var nativeDatabase: TrainPilotDatabase? = null
    private var nativeScope: CoroutineScope? = null

    fun bindNativeEnvironment(
        context: Context,
        settingsStore: TrainPilotSettingsStore,
        database: TrainPilotDatabase,
        scope: CoroutineScope
    ) {
        nativeContext = context
        nativeSettingsStore = settingsStore
        nativeDatabase = database
        nativeScope = scope

        scope.launch(Dispatchers.IO) {
            // 1. Detect if a paused or active workout is running natively
            try {
                val execution = PhoneWorkoutExecution.store(context).snapshot()
                val activeStore = ActiveWorkoutStore.current(context)
                val isPaused = (execution?.optBoolean("active") == true && execution.optBoolean("workoutPaused")) ||
                        (activeStore?.optBoolean("active") == true && activeStore.optBoolean("workoutPaused"))
                val isRunning = (execution?.optBoolean("active") == true && !execution.optBoolean("workoutPaused")) ||
                        (activeStore?.optBoolean("active") == true && !activeStore.optBoolean("workoutPaused"))

                if (isPaused || isRunning) {
                    _uiState.update { it.copy(homeDemoMode = HomeDemoMode.PAUSED_WORKOUT) }
                } else {
                    _uiState.update { it.copy(homeDemoMode = HomeDemoMode.PLANNED_NEXT) }
                }
            } catch (_: Throwable) {}

            // 2. Read all real exercises from Room ExerciseLibrary
            val mappedExercises = try {
                val dbExercises = database.exerciseLibraryDao().getAllExercises()
                if (dbExercises.isNotEmpty()) {
                    dbExercises.map { entity ->
                        val cat = when (entity.primaryMuscle.lowercase()) {
                            "chest" -> ExerciseCategory.CHEST
                            "back" -> ExerciseCategory.BACK
                            "shoulders" -> ExerciseCategory.SHOULDERS
                            "arms", "biceps", "triceps" -> ExerciseCategory.ARMS
                            "legs", "quads", "hamstrings", "calves" -> ExerciseCategory.LEGS
                            "core", "abs" -> ExerciseCategory.CORE
                            else -> ExerciseCategory.OTHER
                        }
                        ExerciseItem(
                            id = entity.id,
                            nameHu = entity.nameHu.ifBlank { entity.nameEn }.ifBlank { entity.id },
                            category = cat,
                            targetMusclesHu = entity.primaryMuscle,
                            equipmentHu = entity.loadType,
                            difficultyHu = "Közepes",
                            defaultSets = 3,
                            defaultReps = entity.defaultReps.toIntOrNull() ?: 10,
                            defaultWeightKg = 0f,
                            defaultRestSec = 90,
                            instructionsHu = listOf("Helyes kivitelezés: ügyelj az egyenes hátra és a kontrollált mozgástartományra."),
                            tipsHu = listOf("Lélegezz egyenletesen és feszíts rá a célizomra."),
                            youtubeVideoUrl = entity.videoUrl ?: ""
                        )
                    }
                } else DemoDataProvider.defaultExercises
            } catch (_: Throwable) { DemoDataProvider.defaultExercises }

            val exercisesMap = mappedExercises.associateBy { it.id }

            // 3. Read real programs and days from Room ProgramDao
            val mappedPrograms = try {
                val dbPrograms = database.programDao().getProgramsWithDays()
                if (dbPrograms.isNotEmpty()) {
                    dbPrograms.mapIndexed { pIdx, pwd ->
                        val prog = pwd.program
                        val days = pwd.days.mapIndexed { dIdx, dayEntity ->
                            val exIds = try {
                                val arr = JSONArray(dayEntity.exercisesJson)
                                (0 until arr.length()).mapNotNull { i ->
                                    val itm = arr.get(i)
                                    if (itm is JSONObject) itm.optString("id") else itm.toString()
                                }
                            } catch (_: Throwable) { emptyList<String>() }
                            val dayExercises = exIds.mapNotNull { exercisesMap[it] }.ifEmpty {
                                mappedExercises.take(6)
                            }
                            com.example.model.ProgramDayModel(
                                dayIndex = dIdx,
                                dayLetter = when (dIdx) { 0 -> "A"; 1 -> "B"; 2 -> "C"; else -> "D" },
                                nameHu = dayEntity.nameHu.ifBlank { "Edzésnap ${dIdx + 1}" },
                                focusHu = "Fő fókusz",
                                durationMinutes = 60,
                                estimatedCalories = 320,
                                intensityHu = "Mérsékelt",
                                exercises = dayExercises
                            )
                        }
                        TrainingProgramModel(
                            id = prog.id,
                            titleHu = prog.nameHu.ifBlank { prog.nameEn }.ifBlank { "Edzésterv ${pIdx + 1}" },
                            subtitleHu = prog.descriptionHu.ifBlank { prog.descriptionEn }.ifBlank { "Heti ${prog.daysPerWeek} napos edzésterv" },
                            isCustom = prog.custom,
                            totalWeeks = prog.totalWeeks.coerceAtLeast(1),
                            daysPerWeek = prog.daysPerWeek.coerceAtLeast(1),
                            levelHu = "Haladó",
                            days = days
                        )
                    }
                } else DemoDataProvider.defaultPrograms
            } catch (_: Throwable) { DemoDataProvider.defaultPrograms }

            // 4. Read latest body weight from Room
            try {
                val weightSummary = database.bodyWeightDao().getWeightJournalSummary()
                if (weightSummary.currentKg != null && weightSummary.currentKg > 0.0) {
                    _uiState.update { it.copy(currentBodyWeightKg = weightSummary.currentKg.toFloat()) }
                }
            } catch (_: Throwable) {}

            // 5. Read persisted workouts from Room
            val mappedWorkouts = try {
                val dbWorkouts = database.workoutHistoryDao().getAllWorkoutsWithDetails()
                dbWorkouts.map { detail ->
                    val w = detail.workout
                    val exerciseNames = detail.exercises.joinToString(", ") { exWithSets ->
                        val ex = exWithSets.exercise
                        ex.nameHu.ifBlank { ex.exerciseId }
                    }
                    val allSets = detail.exercises.flatMap { it.sets }
                    val isOutdoor = detail.exercises.any {
                        val ex = it.exercise
                        ex.measurementType == "distance" || ex.repUnit == "km"
                    }
                    LoggedWorkoutEntry(
                        id = w.id,
                        dateLabelHu = w.started.take(16).replace('T', ' '),
                        titleHu = w.programName.ifBlank { w.dayName }.ifBlank { "Edzés" },
                        durationMinutes = if (w.finishedEpochMs > w.startedEpochMs) ((w.finishedEpochMs - w.startedEpochMs) / 60000).toInt() else 45,
                        workTimeLabel = "30:00",
                        restTimeLabel = "15:00",
                        totalSets = if (w.completedSetsCount > 0) w.completedSetsCount else allSets.size,
                        totalVolumeKg = if (w.totalVolumeKg > 0.0) w.totalVolumeKg.toInt() else allSets.sumOf { ((it.weight ?: 0.0) * (it.reps.toIntOrNull() ?: 0)).toInt() },
                        summaryExercisesHu = exerciseNames.ifBlank { "Rögzített gyakorlatok" },
                        hasPr = w.hasPr226,
                        isOutdoorRun = isOutdoor
                    )
                }
            } catch (_: Throwable) { emptyList() }

            // 6. Read real daily health projections from HealthJournalStore using sleepMinutes
            val todayStr = LocalDate.now().toString()
            var stepsVal = 0
            var restingHrVal = 0
            var currentHrVal = 0
            var activeCalVal = 0
            var sleepStr = "—"
            var sleepDecimal = "—"

            try {
                val store = HealthJournalStore.get(context)
                val projection = store.projection()
                val todayData = projection.optJSONObject("days")?.optJSONObject(todayStr)
                if (todayData != null) {
                    val stepsDbl = todayData.optDouble("steps", Double.NaN)
                    val restingDbl = todayData.optDouble("restingHeartRate", Double.NaN)
                    val currentDbl = todayData.optDouble("heartRate", Double.NaN)
                    val calDbl = todayData.optDouble("activeCalories", Double.NaN)
                    val sleepMinDbl = todayData.optDouble("sleepMinutes", Double.NaN)

                    if (stepsDbl.isFinite() && stepsDbl >= 0) stepsVal = stepsDbl.toInt()
                    if (restingDbl.isFinite() && restingDbl > 0) restingHrVal = restingDbl.toInt()
                    if (currentDbl.isFinite() && currentDbl > 0) currentHrVal = currentDbl.toInt()
                    if (calDbl.isFinite() && calDbl > 0) activeCalVal = calDbl.toInt()
                    if (sleepMinDbl.isFinite() && sleepMinDbl > 0) {
                        sleepStr = String.format("%d ó %d p", (sleepMinDbl / 60).toInt(), (sleepMinDbl % 60).toInt())
                        sleepDecimal = "${((sleepMinDbl / 60.0) * 10.0).roundToInt() / 10.0} h"
                    }
                }
            } catch (_: Throwable) {}

            withContext(Dispatchers.Main) {
                _uiState.update { st ->
                    st.copy(
                        exercises = mappedExercises,
                        selectedExerciseId = mappedExercises.firstOrNull()?.id ?: st.selectedExerciseId,
                        programs = mappedPrograms,
                        editingProgramId = mappedPrograms.firstOrNull()?.id ?: st.editingProgramId,
                        loggedWorkouts = mappedWorkouts,
                        weeklyGoalCompleted = mappedWorkouts.size,
                        dailySteps = if (stepsVal > 0) stepsVal else st.dailySteps,
                        restingHrBpm = if (restingHrVal > 0) restingHrVal else st.restingHrBpm,
                        currentHrBpm = if (currentHrVal > 0) currentHrVal else st.currentHrBpm,
                        activeCaloriesKcal = if (activeCalVal > 0) activeCalVal else st.activeCaloriesKcal,
                        sleepDurationLabel = if (sleepStr != "—") sleepStr else st.sleepDurationLabel,
                        sleepHoursDecimal = if (sleepDecimal != "—") sleepDecimal else st.sleepHoursDecimal
                    )
                }
            }

            // 7. Load real muscle load summary from Room
            loadMuscleLoadSummary(90)
        }
    }

    fun selectTab(tab: MainTab) {
        _uiState.update { state ->
            if (state.currentTab == tab && state.currentSubScreen == SubScreen.NONE) {
                state
            } else {
                val updatedStack = (state.backStack + NavRoute(state.currentTab, state.currentSubScreen)).takeLast(16)
                state.copy(
                    currentTab = tab,
                    currentSubScreen = SubScreen.NONE,
                    backStack = updatedStack
                )
            }
        }
    }

    fun navigateToSubScreen(subScreen: SubScreen, targetTab: MainTab? = null) {
        _uiState.update { state ->
            val updatedStack = (state.backStack + NavRoute(state.currentTab, state.currentSubScreen)).takeLast(16)
            state.copy(
                currentTab = targetTab ?: state.currentTab,
                currentSubScreen = subScreen,
                backStack = updatedStack
            )
        }
    }

    fun navigateBack(): Boolean {
        val current = _uiState.value
        if (current.backStack.isNotEmpty()) {
            val previous = current.backStack.last()
            _uiState.update {
                it.copy(
                    currentTab = previous.tab,
                    currentSubScreen = previous.subScreen,
                    backStack = it.backStack.dropLast(1)
                )
            }
            return true
        } else if (current.currentSubScreen != SubScreen.NONE) {
            _uiState.update { it.copy(currentSubScreen = SubScreen.NONE) }
            return true
        } else if (current.currentTab != MainTab.HOME) {
            _uiState.update { it.copy(currentTab = MainTab.HOME) }
            return true
        }
        return false
    }

    fun selectPalette(paletteId: Int) {
        _uiState.update {
            it.copy(
                selectedPaletteId = paletteId,
                statusBannerMessage = "Színpaletta frissítve (#$paletteId)"
            )
        }
        val store = nativeSettingsStore
        val scope = nativeScope
        if (store != null && scope != null) {
            val pal = TrainPilotPalettes.getById(paletteId)
            val hexAccent = "#" + (pal.primary.value.toLong() and 0xFFFFFFL).toString(16).padStart(6, '0')
            val hexAccent2 = "#" + (pal.secondary.value.toLong() and 0xFFFFFFL).toString(16).padStart(6, '0')
            val option = ThemePaletteOption(
                key = pal.key,
                nameHu = pal.nameHu,
                nameEn = pal.nameEn,
                accent = hexAccent,
                accent2 = hexAccent2,
                family = if (pal.category == PaletteCategory.VIVID) "vivid" else "basic",
                nameDe = pal.nameDe,
                nameRo = pal.nameRo
            )
            scope.launch(Dispatchers.IO) {
                try { store.setTheme(option) } catch (_: Throwable) {}
            }
        }
    }

    fun setPaletteFilterCategory(category: PaletteCategory?) {
        _uiState.update { it.copy(paletteFilterCategory = category) }
    }

    fun togglePalettePickerSheet(show: Boolean) {
        _uiState.update { it.copy(showPalettePickerSheet = show) }
    }

    fun selectLanguage(lang: AppLanguage) {
        _uiState.update {
            it.copy(
                language = lang,
                statusBannerMessage = "Nyelv: ${lang.label} (${lang.code})"
            )
        }
        val store = nativeSettingsStore
        val scope = nativeScope
        if (store != null && scope != null) {
            scope.launch(Dispatchers.IO) {
                try { store.setLanguage(lang.code.lowercase()) } catch (_: Throwable) {}
            }
        }
    }

    fun setFontScaleMultiplier(scale: Float) {
        _uiState.update { it.copy(fontScaleMultiplier = scale) }
    }

    fun toggleCompactPhoneMode(compact: Boolean) {
        _uiState.update { it.copy(compactPhoneMode = compact) }
    }

    fun cycleHomeDemoMode(mode: HomeDemoMode) {
        _uiState.update {
            val readiness = if (mode == HomeDemoMode.COACH_LIGHT_DAY) 54 else 87
            it.copy(
                homeDemoMode = mode,
                coachReadinessScore = readiness,
                samsungEnergyScore = if (mode == HomeDemoMode.COACH_LIGHT_DAY) 61 else 87
            )
        }
    }

    fun toggleGoalsDialog(show: Boolean) {
        _uiState.update { it.copy(showGoalsDialog = show) }
    }

    fun updateGoals(weeklyTarget: Int, stepsTarget: Int) {
        _uiState.update {
            it.copy(
                weeklyGoalTarget = weeklyTarget.coerceIn(1, 30),
                stepsGoal = stepsTarget.coerceIn(2000, 30000),
                showGoalsDialog = false,
                statusBannerMessage = "Célok elmentve: $weeklyTarget edzés, $stepsTarget lépés"
            )
        }
    }

    fun togglePersonalPlannerModal(show: Boolean) {
        _uiState.update { it.copy(showPersonalPlannerModal = show) }
    }

    fun toggleQuickWorkoutSheet(show: Boolean) {
        _uiState.update { it.copy(showQuickWorkoutSheet = show) }
    }

    // Program & Exercise Editor Actions
    fun setProgramsTabCustomOnly(customOnly: Boolean) {
        _uiState.update { it.copy(programsTabCustomOnly = customOnly) }
    }

    fun activateProgram(programId: String) {
        _uiState.update { state ->
            val updated = state.programs.map { prog ->
                prog.copy(isActive = prog.id == programId)
            }
            state.copy(
                programs = updated,
                editingProgramId = programId,
                statusBannerMessage = "Aktív program frissítve"
            )
        }
    }

    fun openProgramEditor(programId: String, dayIndex: Int = 0) {
        _uiState.update {
            val back = (it.backStack + NavRoute(it.currentTab, it.currentSubScreen)).takeLast(16)
            it.copy(
                editingProgramId = programId,
                editingDayIndex = dayIndex,
                currentSubScreen = SubScreen.PROGRAM_EDITOR,
                backStack = back
            )
        }
    }

    fun selectEditingDayIndex(dayIndex: Int) {
        _uiState.update { it.copy(editingDayIndex = dayIndex) }
    }

    fun toggleExpandedEditorExercise(exerciseId: String) {
        _uiState.update {
            it.copy(
                expandedEditorExerciseId = if (it.expandedEditorExerciseId == exerciseId) null else exerciseId
            )
        }
    }

    fun updateProgramExercisePrescription(
        exerciseId: String,
        sets: Int,
        reps: Int,
        weightKg: Float,
        restSec: Int
    ) {
        _uiState.update { state ->
            val updatedPrograms = state.programs.map { prog ->
                if (prog.id != state.editingProgramId) prog
                else {
                    val updatedDays = prog.days.mapIndexed { idx, day ->
                        if (idx != state.editingDayIndex) day
                        else {
                            day.copy(
                                exercises = day.exercises.map { ex ->
                                    if (ex.id != exerciseId) ex
                                    else ex.copy(
                                        defaultSets = sets.coerceIn(1, 10),
                                        defaultReps = reps.coerceIn(1, 50),
                                        defaultWeightKg = weightKg.coerceAtLeast(0f),
                                        defaultRestSec = restSec.coerceIn(15, 300)
                                    )
                                }
                            )
                        }
                    }
                    prog.copy(days = updatedDays)
                }
            }
            state.copy(
                programs = updatedPrograms,
                expandedEditorExerciseId = null,
                statusBannerMessage = "Gyakorlat beállításai elmentve"
            )
        }
    }

    fun addExerciseToActiveProgramDay(exercise: ExerciseItem) {
        _uiState.update { state ->
            val updatedPrograms = state.programs.map { prog ->
                if (prog.id != state.editingProgramId) prog
                else {
                    val updatedDays = prog.days.mapIndexed { idx, day ->
                        if (idx != state.editingDayIndex) day
                        else if (day.exercises.any { it.id == exercise.id }) day
                        else day.copy(exercises = day.exercises + exercise)
                    }
                    prog.copy(days = updatedDays)
                }
            }
            state.copy(
                programs = updatedPrograms,
                statusBannerMessage = "${exercise.nameHu} hozzáadva az edzésnaphoz"
            )
        }
    }

    // Calendar & Replan Actions
    fun selectCalendarDay(day: Int) {
        _uiState.update { it.copy(selectedCalendarDay = day) }
    }

    fun toggleReplanModal(show: Boolean) {
        _uiState.update { it.copy(showReplanModal = show) }
    }

    fun applyCalendarReplan(newStartDate: String, firstDayHu: String) {
        _uiState.update { state ->
            val shiftedEvents = state.calendarEvents.map { ev ->
                if (ev.status == CalendarEventStatus.PLANNED && ev.dayOfMonth >= 27) {
                    ev.copy(dayOfMonth = (ev.dayOfMonth + 1).coerceAtMost(31))
                } else ev
            }
            state.copy(
                planningStartDate = newStartDate,
                planningFirstDayHu = firstDayHu,
                calendarEvents = shiftedEvents,
                showReplanModal = false,
                statusBannerMessage = "Edzésterv újratervezve ($newStartDate • $firstDayHu)"
            )
        }
    }

    // Exercise Library Actions
    fun updateExerciseSearch(query: String) {
        _uiState.update { it.copy(exerciseSearchQuery = query) }
    }

    fun selectExerciseCategory(cat: ExerciseCategory) {
        _uiState.update { it.copy(selectedExerciseCategory = cat) }
    }

    fun openExerciseDetail(exerciseId: String) {
        _uiState.update {
            val back = (it.backStack + NavRoute(it.currentTab, it.currentSubScreen)).takeLast(16)
            it.copy(
                selectedExerciseId = exerciseId,
                currentSubScreen = SubScreen.EXERCISE_DETAIL,
                backStack = back
            )
        }
    }

    // Active Workout Actions
    fun toggleSetCompleted(setNumber: Int) {
        _uiState.update { state ->
            val updated = state.activeSets.map { s ->
                if (s.setNumber == setNumber) s.copy(completed = !s.completed) else s
            }
            state.copy(
                activeSets = updated,
                restTimerRemainingSec = state.defaultRestSec,
                restTimerRunning = true
            )
        }
    }

    fun adjustSetValues(setNumber: Int, deltaWeight: Float, deltaReps: Int, deltaRir: Int) {
        _uiState.update { state ->
            val updated = state.activeSets.map { s ->
                if (s.setNumber == setNumber) {
                    s.copy(
                        weightKg = (s.weightKg + deltaWeight).coerceAtLeast(0f),
                        reps = (s.reps + deltaReps).coerceIn(1, 50),
                        rir = (s.rir + deltaRir).coerceIn(0, 10)
                    )
                } else s
            }
            state.copy(activeSets = updated)
        }
    }

    fun undoLastCompletedSet() {
        _uiState.update { state ->
            val lastCompleted = state.activeSets.lastOrNull { it.completed }
            if (lastCompleted == null) state
            else {
                state.copy(
                    activeSets = state.activeSets.map {
                        if (it.setNumber == lastCompleted.setNumber) it.copy(completed = false) else it
                    },
                    statusBannerMessage = "${lastCompleted.setNumber}. sorozat visszavonva"
                )
            }
        }
    }

    fun adjustRestTimer(deltaSec: Int) {
        _uiState.update {
            it.copy(restTimerRemainingSec = (it.restTimerRemainingSec + deltaSec).coerceIn(0, 600))
        }
    }

    fun toggleRestTimerRunning() {
        _uiState.update { it.copy(restTimerRunning = !it.restTimerRunning) }
    }

    fun skipRestTimer() {
        _uiState.update { it.copy(restTimerRemainingSec = 0, restTimerRunning = false) }
    }

    fun updateIntervalSettings(workSec: Int, restSec: Int, rounds: Int, sound: Boolean, vibration: Boolean, autoStep: Boolean) {
        _uiState.update {
            it.copy(
                intervalWorkSec = workSec.coerceIn(10, 300),
                intervalRestSec = restSec.coerceIn(10, 300),
                intervalRounds = rounds.coerceIn(1, 20),
                soundAlertEnabled = sound,
                vibrationEnabled = vibration,
                autoStepIntervals = autoStep,
                statusBannerMessage = "Intervallumok: ${workSec}mp munka / ${restSec}mp pihenő × $rounds"
            )
        }
    }

    fun selectWorkoutSummaryMood(index: Int) {
        _uiState.update { it.copy(workoutSummaryMoodIndex = index) }
    }

    fun updateWorkoutSummaryNote(note: String) {
        _uiState.update { it.copy(workoutSummaryNote = note) }
    }

    fun finishAndSaveWorkout() {
        val state = _uiState.value
        val now = Instant.now()
        val nowMs = System.currentTimeMillis()
        val workoutId = UUID.randomUUID().toString()
        val completedSets = state.activeSets.filter { it.completed }
        val setsToSave = if (completedSets.isNotEmpty()) completedSets else state.activeSets
        val totalVolume = setsToSave.sumOf { (it.weightKg * it.reps).toInt() }
        val currentExName = state.exercises.getOrNull(state.activeExerciseIndex)?.nameHu ?: "Edzés"
        val durationMins = maxOf(1, state.timedCurrentSec / 60)

        val ctx = nativeContext
        val db = nativeDatabase
        val store = nativeSettingsStore
        val scope = nativeScope

        if (ctx == null || db == null || store == null || scope == null) {
            _uiState.update { it.copy(statusBannerMessage = "Hiba: A natív edzésmotor nem elérhető!") }
            return
        }

        scope.launch(Dispatchers.IO) {
            try {
                val exercisesArray = JSONArray()
                val exObj = JSONObject().apply {
                    put("id", state.selectedExerciseId.ifBlank { "ex-0" })
                    put("exerciseId", state.selectedExerciseId.ifBlank { "ex-0" })
                    put("nameHu", currentExName)
                    put("nameEn", currentExName)
                    put("loadType", "weight")
                    put("repUnit", "reps")
                    put("measurementType", "reps")
                    put("orderIndex", 0)
                    val setsArray = JSONArray()
                    setsToSave.forEachIndexed { idx, s ->
                        setsArray.put(JSONObject().apply {
                            put("setId", UUID.randomUUID().toString())
                            put("set", idx + 1)
                            put("setNumber", s.setNumber)
                            put("weight", s.weightKg.toDouble())
                            put("reps", s.reps.toString())
                            put("done", s.completed)
                            put("actualRir", s.rir)
                        })
                    }
                    put("sets", setsArray)
                }
                exercisesArray.put(exObj)

                val startedMs = nowMs - (durationMins * 60 * 1000L)
                val candidateJson = JSONObject().apply {
                    put("schema", 1)
                    put("active", true)
                    put("id", workoutId)
                    put("workoutId", workoutId)
                    put("workoutKey", workoutId)
                    put("syncId", workoutId)
                    put("started", Instant.ofEpochMilli(startedMs).toString())
                    put("finished", now.toString())
                    put("startedEpochMs", startedMs)
                    put("finishedEpochMs", nowMs)
                    put("programId", state.editingProgramId.ifBlank { "program_custom" })
                    put("programName", "Edzés – $currentExName")
                    put("dayId", "session")
                    put("dayName", currentExName)
                    put("workout", currentExName)
                    put("totalVolumeKg", totalVolume.toDouble())
                    put("completedSetsCount", setsToSave.size)
                    put("totalSetsCount", setsToSave.size)
                    put("timerOwner", "phone")
                    put("originDevice", "phone")
                    put("workoutPaused", false)
                    put("exercises", exercisesArray)
                    if (state.workoutSummaryNote.isNotBlank() || state.workoutSummaryMoodIndex >= 0) {
                        put("feedback", JSONObject().apply {
                            put("effort", when (state.workoutSummaryMoodIndex) {
                                0 -> "könnyű"
                                1 -> "mérsékelt"
                                2 -> "pont jó"
                                3 -> "nehéz"
                                else -> "maximális"
                            })
                            put("note", state.workoutSummaryNote)
                            put("updatedAt", nowMs)
                        })
                    }
                }

                // Check or install session in ActiveWorkoutStore & PhoneWorkoutExecution
                val existingActive = ActiveWorkoutStore.current(ctx)
                val activeToFinalize = if (existingActive?.optBoolean("active") == true && existingActive.optString("timerOwner", "phone") == "phone") {
                    existingActive.put("finished", now.toString())
                    existingActive.put("finishedEpochMs", nowMs)
                    if (candidateJson.has("feedback")) existingActive.put("feedback", candidateJson.getJSONObject("feedback"))
                    if (!existingActive.has("exercises") || existingActive.getJSONArray("exercises").length() == 0) {
                        existingActive.put("exercises", exercisesArray)
                    }
                    existingActive
                } else {
                    withContext(Dispatchers.Main.immediate) {
                        NativeWorkoutSession.installPrepared(ctx, candidateJson)
                    }
                }

                // Canonical native finalization:
                // locks mutex, evaluates PRs via PersonalRecordCalculator226, updates calendar schedule,
                // performs atomic Room transaction, tears down PhoneWorkoutExecution, clears ActiveWorkoutStore!
                val finalizer = TrainPilotWorkoutFinalization(ctx, db)
                val saved = finalizer.finishWorkout(activeToFinalize)

                // Verify persistence by querying Room directly
                val finalWorkoutId = saved.history.optString("workoutId", workoutId)
                val savedInDb = db.workoutHistoryDao().getWorkoutWithDetails(finalWorkoutId)
                if (savedInDb != null) {
                    saved.closedSnapshot?.let { runCatching { WearSyncRepository.publishActiveWorkoutSnapshot(ctx, it) } }
                    runCatching { WearSyncRepository.refreshWatchHomeAsync(ctx) }
                    runCatching { WearSyncRepository.publishWatchHomeSnapshot(ctx) }

                    val newEntry = LoggedWorkoutEntry(
                        id = finalWorkoutId,
                        dateLabelHu = DateTimeFormatter.ofPattern("MMM d., E • HH:mm", Locale.getDefault()).format(java.time.LocalDateTime.now()),
                        titleHu = "$currentExName edzés",
                        durationMinutes = durationMins,
                        workTimeLabel = String.format("%02d:%02d", durationMins, 0),
                        restTimeLabel = "00:00",
                        totalSets = setsToSave.size,
                        totalVolumeKg = totalVolume,
                        summaryExercisesHu = currentExName,
                        hasPr = savedInDb.workout.hasPr226,
                        isOutdoorRun = false
                    )

                    withContext(Dispatchers.Main) {
                        _uiState.update { st ->
                            st.copy(
                                loggedWorkouts = listOf(newEntry) + st.loggedWorkouts,
                                weeklyGoalCompleted = st.weeklyGoalCompleted + 1,
                                currentTab = MainTab.LOG,
                                currentSubScreen = SubScreen.NONE,
                                statusBannerMessage = "Edzés sikeresen lezárva és mentve a Room adatbázisba!"
                            )
                        }
                    }
                    loadMuscleLoadSummary(90)
                } else {
                    withContext(Dispatchers.Main) {
                        _uiState.update { st ->
                            st.copy(statusBannerMessage = "Hiba: Az edzés mentése nem igazolható vissza a Room adatbázisból!")
                        }
                    }
                }
            } catch (e: Throwable) {
                android.util.Log.e("TrainPilotViewModel", "Failed to finalize workout canonically", e)
                withContext(Dispatchers.Main) {
                    _uiState.update { st ->
                        st.copy(statusBannerMessage = "Hiba az edzés mentésekor: ${e.localizedMessage ?: "adatbázishiba"}")
                    }
                }
            }
        }
    }

    // Log / Diary Actions
    fun updateLogSearch(query: String) {
        _uiState.update { it.copy(logSearchQuery = query) }
    }

    fun openLogWorkoutDetail(workoutId: String) {
        _uiState.update {
            val back = (it.backStack + NavRoute(it.currentTab, it.currentSubScreen)).takeLast(16)
            it.copy(
                selectedLogWorkoutId = workoutId,
                currentSubScreen = SubScreen.LOG_WORKOUT_DETAIL,
                backStack = back
            )
        }
    }

    fun selectLogDetailTab(index: Int) {
        _uiState.update { it.copy(logDetailTabIndex = index) }
    }

    fun toggleExpandedLogExercise(index: Int) {
        _uiState.update {
            it.copy(expandedLogExerciseIndex = if (it.expandedLogExerciseIndex == index) -1 else index)
        }
    }

    // Progress / Fejlődés Actions
    fun selectProgressMainSection(section: Int) {
        _uiState.update { it.copy(progressMainSection = section) }
    }

    fun selectProgressExercise(name: String) {
        _uiState.update { it.copy(selectedProgressExercise = name) }
    }

    fun selectProgressRange(index: Int) {
        _uiState.update { it.copy(selectedProgressRangeIndex = index) }
    }

    fun selectVolumeBar(index: Int) {
        _uiState.update { it.copy(selectedVolumeBarIndex = index) }
    }

    fun selectExpandedStatsCard(index: Int) {
        _uiState.update {
            it.copy(expandedStatsCardIndex = if (it.expandedStatsCardIndex == index) -1 else index)
        }
    }

    fun selectStatsSubTab(index: Int) {
        _uiState.update { it.copy(statsSubTab = index) }
    }

    fun toggleCardioFilterStepsMode(stepsMode: Boolean) {
        _uiState.update { it.copy(cardioFilterStepsMode = stepsMode) }
    }

    fun openExerciseVideoModal(exerciseTitle: String) {
        _uiState.update { it.copy(videoModalExerciseTitle = exerciseTitle) }
    }

    fun closeExerciseVideoModal() {
        _uiState.update { it.copy(videoModalExerciseTitle = null) }
    }

    // Health / Egészség Actions
    fun openHealthAndExpand(
        pulse: Boolean = false,
        weight: Boolean = false,
        extra: Boolean = false,
        journal: Boolean = false,
        connect: Boolean = false
    ) {
        _uiState.update { state ->
            val back = (state.backStack + NavRoute(state.currentTab, state.currentSubScreen)).takeLast(16)
            state.copy(
                currentTab = MainTab.HEALTH,
                currentSubScreen = SubScreen.NONE,
                backStack = back,
                expandedHealthPulseTrend = pulse || state.expandedHealthPulseTrend,
                expandedHealthWeightLog = weight || state.expandedHealthWeightLog,
                expandedHealthExtraData = extra || state.expandedHealthExtraData,
                expandedHealthJournal = journal || state.expandedHealthJournal,
                expandedHealthConnect = connect || state.expandedHealthConnect
            )
        }
    }

    fun toggleHealthSection(section: String) {
        _uiState.update { state ->
            when (section) {
                "pulse" -> state.copy(expandedHealthPulseTrend = !state.expandedHealthPulseTrend)
                "weight" -> state.copy(expandedHealthWeightLog = !state.expandedHealthWeightLog)
                "extra" -> state.copy(expandedHealthExtraData = !state.expandedHealthExtraData)
                "journal" -> state.copy(expandedHealthJournal = !state.expandedHealthJournal)
                "connect" -> state.copy(expandedHealthConnect = !state.expandedHealthConnect)
                else -> state
            }
        }
    }

    fun selectWeightRange(index: Int) {
        _uiState.update { it.copy(selectedWeightRangeIndex = index) }
    }

    fun toggleAddWeightDialog(show: Boolean) {
        _uiState.update { it.copy(showAddWeightDialog = show) }
    }

    fun saveNewBodyWeight(weightKg: Float) {
        if (weightKg <= 20f || weightKg >= 350f) {
            _uiState.update { it.copy(statusBannerMessage = "Érvénytelen testsúly: 20 és 350 kg között adható meg!") }
            return
        }
        val db = nativeDatabase
        val scope = nativeScope
        if (db == null || scope == null) {
            _uiState.update { it.copy(statusBannerMessage = "Hiba: Az adatbázis nem elérhető!") }
            return
        }
        scope.launch(Dispatchers.IO) {
            try {
                val now = Instant.now()
                val todayKey = LocalDate.now().toString()
                val entry = BodyWeightEntryEntity(
                    id = UUID.randomUUID().toString(),
                    date = now.toString(),
                    dayKey = todayKey,
                    kg = weightKg.toDouble(),
                    updatedAt = System.currentTimeMillis(),
                    rawJson = JSONObject().put("kg", weightKg.toDouble()).put("date", now.toString()).toString()
                )
                db.bodyWeightDao().upsertWeight(entry)
                // Verify by reading back from DB!
                val verified = db.bodyWeightDao().getWeightJournalSummary()
                if (verified.currentKg != null && Math.abs(verified.currentKg - weightKg.toDouble()) < 0.1) {
                    withContext(Dispatchers.Main) {
                        _uiState.update {
                            it.copy(
                                currentBodyWeightKg = weightKg,
                                showAddWeightDialog = false,
                                statusBannerMessage = "Testsúlymérés sikeresen elmentve: $weightKg kg"
                            )
                        }
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        _uiState.update {
                            it.copy(statusBannerMessage = "Hiba: A testsúlymérés nem rögzült az adatbázisban!")
                        }
                    }
                }
            } catch (e: Throwable) {
                android.util.Log.e("TrainPilotViewModel", "Failed to save body weight to Room", e)
                withContext(Dispatchers.Main) {
                    _uiState.update {
                        it.copy(statusBannerMessage = "Nem sikerült elmenteni a testsúlymérést: ${e.localizedMessage ?: "adatbázishiba"}")
                    }
                }
            }
        }
    }

    fun togglePrimaryHealthSource() {
        _uiState.update {
            val next = !it.primaryHealthSourceSamsung
            it.copy(
                primaryHealthSourceSamsung = next,
                statusBannerMessage = if (next) "Elsődleges forrás: Samsung Health" else "Elsődleges forrás: Health Connect"
            )
        }
    }

    fun triggerHealthSyncNow() {
        val ctx = nativeContext
        val scope = nativeScope
        if (ctx == null || scope == null) {
            _uiState.update {
                it.copy(statusBannerMessage = "Az egészségügyi szolgáltatások nem elérhetők.")
            }
            return
        }
        scope.launch(Dispatchers.IO) {
            try {
                HealthBackgroundJob.schedule(ctx)
                WearSyncRepository.publishWatchHomeSnapshot(ctx)
                val store = HealthJournalStore.get(ctx)
                val todayStr = LocalDate.now().toString()
                val page = store.page(LocalDate.now().minusDays(1).toString(), todayStr, "journal", "", 0L, 0L, 1)
                val summaries = page.optJSONArray("days")
                val daysList = (0 until (summaries?.length() ?: 0)).mapNotNull { summaries?.optJSONObject(it) }
                val todayData = daysList.firstOrNull { it.optString("day") == todayStr } ?: store.projection().optJSONObject("days")?.optJSONObject(todayStr)

                val stepsDbl = todayData?.optDouble("steps", Double.NaN) ?: Double.NaN
                val pulseDbl = todayData?.optDouble("averageHeartRate", Double.NaN) ?: Double.NaN
                val restingDbl = todayData?.optDouble("restingHeartRate", Double.NaN) ?: Double.NaN
                val caloriesDbl = todayData?.optDouble("activeCalories", Double.NaN) ?: Double.NaN
                val sleepMinDbl = todayData?.optDouble("sleepMinutes", Double.NaN) ?: Double.NaN

                val hasData = (stepsDbl.isFinite() && stepsDbl > 0) || (pulseDbl.isFinite() && pulseDbl > 0) || (sleepMinDbl.isFinite() && sleepMinDbl > 0)

                withContext(Dispatchers.Main) {
                    _uiState.update { st ->
                        st.copy(
                            dailySteps = if (stepsDbl.isFinite() && stepsDbl >= 0) stepsDbl.toInt() else st.dailySteps,
                            currentHrBpm = if (pulseDbl.isFinite() && pulseDbl > 0) pulseDbl.toInt() else st.currentHrBpm,
                            restingHrBpm = if (restingDbl.isFinite() && restingDbl > 0) restingDbl.toInt() else st.restingHrBpm,
                            activeCaloriesKcal = if (caloriesDbl.isFinite() && caloriesDbl > 0) caloriesDbl.toInt() else st.activeCaloriesKcal,
                            sleepDurationLabel = if (sleepMinDbl.isFinite() && sleepMinDbl > 0) String.format("%d ó %d p", (sleepMinDbl / 60).toInt(), (sleepMinDbl % 60).toInt()) else st.sleepDurationLabel,
                            sleepHoursDecimal = if (sleepMinDbl.isFinite() && sleepMinDbl > 0) "${((sleepMinDbl / 60.0) * 10.0).roundToInt() / 10.0} h" else st.sleepHoursDecimal,
                            statusBannerMessage = if (hasData) "Egészségügyi adatok sikeresen szinkronizálva!" else "Szinkronizáció lefutott. Nincs új elérhető adat a szolgáltatótól."
                        )
                    }
                }
            } catch (e: Throwable) {
                withContext(Dispatchers.Main) {
                    _uiState.update {
                        it.copy(statusBannerMessage = "Hiba az egészségszinkron során: ${e.localizedMessage ?: "szolgáltatói hiba"}")
                    }
                }
            }
        }
    }

    // Watch, Settings, Backup & Permissions Actions
    fun toggleWatchControlMode() {
        val ctx = nativeContext
        val scope = nativeScope
        if (ctx == null || scope == null) {
            _uiState.update { it.copy(statusBannerMessage = "A Wear OS szolgáltatás jelenleg nem elérhető.") }
            return
        }
        scope.launch(Dispatchers.IO) {
            try {
                val active = ActiveWorkoutStore.current(ctx)
                if (active == null || !active.optBoolean("active", false)) {
                    withContext(Dispatchers.Main) {
                        _uiState.update {
                            it.copy(
                                phoneControlsWorkout = true,
                                watchControlPending = false,
                                statusBannerMessage = "Nincs aktív edzés folyamatban az órára történő átadáshoz."
                            )
                        }
                    }
                    return@launch
                }
                val currentOwner = active.optString("timerOwner", "phone")
                if (currentOwner == "phone") {
                    withContext(Dispatchers.Main) {
                        _uiState.update {
                            it.copy(
                                watchControlPending = true,
                                statusBannerMessage = "Átadási kérelem elküldve az órának... Várakozás a nyugtázásra."
                            )
                        }
                    }
                    WearSyncRepository.publishWatchHomeSnapshot(ctx)
                    kotlinx.coroutines.delay(600)
                    withContext(Dispatchers.Main) {
                        _uiState.update {
                            it.copy(
                                phoneControlsWorkout = false,
                                watchControlPending = false,
                                lastWatchSyncLabel = "Átadva az órára",
                                statusBannerMessage = "Az edzésvezérlés sikeresen átadva az órának."
                            )
                        }
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        _uiState.update {
                            it.copy(
                                watchControlPending = true,
                                statusBannerMessage = "Edzésvezérlés visszakérése a telefonra..."
                            )
                        }
                    }
                    runCatching {
                        PhoneOwnership193.journal(ctx).recover()
                        val resume = PhoneOwnership193.prepareResume(ctx)
                        val reqId = resume.optJSONObject("snapshot")?.optJSONObject("ownershipImport193")?.optString("id") ?: ""
                        val epoch = resume.optJSONObject("snapshot")?.optLong("ownerEpoch193") ?: 0L
                        PhoneOwnership193.installResume(ctx, reqId, epoch)
                    }
                    withContext(Dispatchers.Main) {
                        _uiState.update {
                            it.copy(
                                phoneControlsWorkout = true,
                                watchControlPending = false,
                                lastWatchSyncLabel = "Telefon vezérel",
                                statusBannerMessage = "Edzésvezérlés visszavéve a telefonra."
                            )
                        }
                    }
                }
            } catch (e: Throwable) {
                withContext(Dispatchers.Main) {
                    _uiState.update {
                        it.copy(
                            watchControlPending = false,
                            statusBannerMessage = "Hiba az óra átadásakor: ${e.localizedMessage ?: "kapcsolati hiba"}"
                        )
                    }
                }
            }
        }
    }

    fun loadMuscleLoadSummary(days: Int = 90) {
        val db = nativeDatabase ?: return
        val scope = nativeScope ?: return
        val lang = _uiState.value.language.name.lowercase()
        scope.launch(Dispatchers.IO) {
            try {
                val now = System.currentTimeMillis()
                val fromEpoch = now - (days * 24L * 3600L * 1000L)
                val summaries = db.workoutHistoryDao().getProgressMuscleSummary(fromEpoch, now)
                val models = NativeProgressQuery.muscle(summaries, lang)
                val items = models.map { m ->
                    val percentage = (m.ratio * 100).toInt()
                    val level = when {
                        m.setsCount == 0 -> "Nincs terhelés"
                        m.ratio >= 0.75f -> "Nagyobb terhelés"
                        m.ratio >= 0.4f -> "Közepes terhelés"
                        else -> "Kisebb terhelés"
                    }
                    com.example.ui.components.MuscleLoadItem(
                        id = m.key,
                        nameHu = m.label,
                        setsText = if (m.setsCount > 0) "${m.setsCount} sorozat" else "0 sorozat",
                        percentage = percentage,
                        ratio = m.ratio,
                        levelLabelHu = level,
                        topExercisesHu = emptyList(),
                        exerciseIdToOpen = ""
                    )
                }
                withContext(Dispatchers.Main) {
                    _uiState.update { it.copy(realMuscleLoads = items, muscleLoadPeriodDays = days) }
                }
            } catch (e: Throwable) {
                android.util.Log.e("TrainPilotViewModel", "Failed to load real muscle summary", e)
            }
        }
    }

    fun exportBackup(context: Context, uri: Uri, format: String) {
        val scope = nativeScope ?: return
        scope.launch(Dispatchers.IO) {
            try {
                val mgr = BackupRestoreManager(context)
                val result = if (format.lowercase().contains("zip")) {
                    mgr.exportZipArchiveToUri(uri).map { "${it.first} (${it.second / 1024} KB)" }
                } else {
                    mgr.exportJsonBackupToUri(uri).map { "${it.first} (${it.second} bájt)" }
                }
                withContext(Dispatchers.Main) {
                    _uiState.update {
                        it.copy(
                            statusBannerMessage = if (result.isSuccess) "Biztonsági mentés sikeresen elkészült: ${result.getOrNull()}"
                            else "Hiba a mentés során: ${result.exceptionOrNull()?.localizedMessage}"
                        )
                    }
                }
            } catch (e: Throwable) {
                withContext(Dispatchers.Main) {
                    _uiState.update {
                        it.copy(statusBannerMessage = "Nem sikerült a mentés: ${e.localizedMessage ?: "fájlírási hiba"}")
                    }
                }
            }
        }
    }

    fun importBackup(context: Context, uri: Uri) {
        val scope = nativeScope ?: return
        scope.launch(Dispatchers.IO) {
            try {
                val mgr = BackupRestoreManager(context)
                val isZip = uri.toString().endsWith(".zip", ignoreCase = true) || context.contentResolver.getType(uri)?.contains("zip") == true
                val result = if (isZip) {
                    mgr.importZipArchiveFromUri(uri, recoverInterrupted = false)
                } else {
                    mgr.importJsonBackupFromUri(uri, recoverInterrupted = false)
                }
                withContext(Dispatchers.Main) {
                    _uiState.update {
                        it.copy(
                            statusBannerMessage = if (result.isSuccess) "Biztonsági mentés sikeresen visszaállítva!"
                            else "Hiba a visszaállítás során: ${result.exceptionOrNull()?.localizedMessage}"
                        )
                    }
                }
                nativeDatabase?.let { db ->
                    nativeSettingsStore?.let { store ->
                        bindNativeEnvironment(context, store, db, scope)
                    }
                }
            } catch (e: Throwable) {
                withContext(Dispatchers.Main) {
                    _uiState.update {
                        it.copy(statusBannerMessage = "Nem sikerült a visszaállítás: ${e.localizedMessage ?: "olvasási hiba"}")
                    }
                }
            }
        }
    }

    fun toggleSoundAlert(enabled: Boolean) {
        _uiState.update { it.copy(soundAlertEnabled = enabled) }
        val store = nativeSettingsStore
        val scope = nativeScope
        if (store != null && scope != null) {
            val current = _uiState.value
            scope.launch(Dispatchers.IO) {
                try {
                    store.setTimerDefaults(
                        workSeconds = 30,
                        restSeconds = current.defaultRestSec,
                        rounds = 3,
                        sound = enabled,
                        vibration = current.vibrationEnabled
                    )
                } catch (_: Throwable) {}
            }
        }
    }

    fun cycleDefaultRestTimer() {
        _uiState.update {
            val next = when (it.defaultRestSec) {
                60 -> 90
                90 -> 120
                120 -> 180
                else -> 60
            }
            it.copy(defaultRestSec = next, statusBannerMessage = "Alapértelmezett pihenőidő: $next mp")
        }
        val store = nativeSettingsStore
        val scope = nativeScope
        if (store != null && scope != null) {
            val current = _uiState.value
            scope.launch(Dispatchers.IO) {
                try {
                    store.setTimerDefaults(
                        workSeconds = 30,
                        restSeconds = current.defaultRestSec,
                        rounds = 3,
                        sound = current.soundAlertEnabled,
                        vibration = current.vibrationEnabled
                    )
                } catch (_: Throwable) {}
            }
        }
    }

    fun toggleProgressionModal(show: Boolean) {
        _uiState.update { it.copy(showProgressionModal = show) }
    }

    fun updateProgressionSettings(styleHu: String, ruleHu: String, gentleBeginner: Boolean) {
        _uiState.update {
            it.copy(
                trainingStyleHu = styleHu,
                progressionRuleHu = ruleHu,
                beginnerGentleProfileActive = gentleBeginner,
                showProgressionModal = false,
                statusBannerMessage = "Progresszió: $styleHu • $ruleHu"
            )
        }
    }

    fun selectBackupFormat(format: String) {
        _uiState.update { it.copy(selectedBackupFormat = format) }
    }

    fun toggleIncludeHealthInBackup(include: Boolean) {
        _uiState.update { it.copy(includeHealthInBackup = include) }
    }

    fun togglePermission(key: String) {
        _uiState.update { state ->
            when (key) {
                "gps" -> state.copy(permissionGpsEnabled = !state.permissionGpsEnabled)
                "central" -> state.copy(permissionCentralLocEnabled = !state.permissionCentralLocEnabled)
                "notif" -> state.copy(permissionNotificationsEnabled = !state.permissionNotificationsEnabled)
                "hc" -> state.copy(permissionHealthConnectEnabled = !state.permissionHealthConnectEnabled)
                "samsung" -> state.copy(permissionSamsungHealthEnabled = !state.permissionSamsungHealthEnabled)
                else -> state
            }
        }
    }

    fun showBannerMessage(message: String) {
        _uiState.update { it.copy(statusBannerMessage = message) }
    }

    fun clearBannerMessage() {
        _uiState.update { it.copy(statusBannerMessage = null) }
    }

    fun syncNativeSettings(
        languageCode: String,
        themeKey: String,
        restSec: Int = 90,
        sound: Boolean = true,
        vibration: Boolean = true
    ) {
        val lang = when (languageCode.lowercase()) {
            "en" -> AppLanguage.EN
            "de" -> AppLanguage.DE
            "ro" -> AppLanguage.RO
            else -> AppLanguage.HU
        }
        val palette = com.example.ui.theme.TrainPilotPalettes.getByKey(themeKey)
        _uiState.update { current ->
            current.copy(
                language = lang,
                selectedPaletteId = palette?.id ?: current.selectedPaletteId,
                defaultRestSec = if (restSec > 0) restSec else current.defaultRestSec,
                soundAlertEnabled = sound,
                vibrationEnabled = vibration
            )
        }
    }
}
